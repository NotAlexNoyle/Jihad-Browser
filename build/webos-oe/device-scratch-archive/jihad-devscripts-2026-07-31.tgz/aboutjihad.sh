#!/bin/sh
D=/media/internal/jihad
CP=$(luna-send -n 1 palm://com.palm.applicationManager/running '{}' 2>/dev/null | sed 's/},{/}\n{/g' | grep -i jihad | grep -oiE 'processid[": ]+[0-9]+' | grep -oE '[0-9]+' | head -1)
[ -n "$CP" ] && luna-send -n 1 palm://com.palm.applicationManager/close "{\"processId\":\"$CP\"}" 2>/dev/null >/dev/null
sleep 2
luna-send -n 1 palm://com.palm.applicationManager/launch '{"id":"net.riverstonerelay.jihad-browser","params":{"target":"about:jihad"}}' 2>&1 | head -1
sleep 8
echo "=== about:jihad loaded? ==="
tail -6 "$D/upstart-daemon.log" 2>/dev/null | grep -aiE 'openUrl|load done|painted bytes|setHtml|about'
echo "=== health ==="
echo " daemon:$(ps -ef|grep -c '[j]ihad-browserserver') socket:$(ls /tmp/yapserver.jihad-browser 2>/dev/null||echo NONE) card:$(luna-send -n 1 palm://com.palm.applicationManager/running '{}' 2>/dev/null|grep -c jihad)"
echo " idle%: $(top -bn1 2>/dev/null | sed -n '3p' | grep -oE '[0-9.]+%id' | head -1)  load:$(cut -d' ' -f1-3 /proc/loadavg)"
