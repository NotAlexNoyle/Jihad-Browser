#!/bin/sh
mount -o remount,rw / 2>/dev/null
cp /media/internal/jihad/BrowserAdapter.so /usr/lib/BrowserPlugins/BrowserAdapter.so
chmod 755 /usr/lib/BrowserPlugins/BrowserAdapter.so
rm -f /media/internal/jihad/adapter.log
echo "adapter installed: $(ls -la /usr/lib/BrowserPlugins/BrowserAdapter.so | awk '{print $5}')"
