#!/bin/sh
D=/media/internal/jihad
echo "=== install adapter (rw window) ==="
mount -o remount,rw / 2>/dev/null
cp "$D/BrowserAdapterJihad.so" /usr/lib/BrowserPlugins/BrowserAdapterJihad.so
chmod 755 /usr/lib/BrowserPlugins/BrowserAdapterJihad.so
sync; mount -o remount,ro / 2>/dev/null
echo " installed md5: $(md5sum /usr/lib/BrowserPlugins/BrowserAdapterJihad.so | cut -d' ' -f1)"
echo "=== restart LunaSysMgr (fresh dlopen of the replaced plugin) ==="
killall LunaSysMgr 2>/dev/null
i=0; while [ $i -lt 25 ]; do sleep 2; [ "$(ps -ef 2>/dev/null|grep -c '[L]unaSysMgr')" -ge 1 ] && { echo "LunaSysMgr back ~$((i*2+2))s"; break; }; i=$((i+1)); done
sleep 4
echo " daemon:$(ps -ef|grep -c '[j]ihad-browserserver') luna:$(ps -ef|grep -c '[L]unaSysMgr') load:$(cut -d' ' -f1-3 /proc/loadavg)"
