#!/bin/sh
echo "=== adapter .so on device ==="
find /media/internal/jihad -name '*.so' 2>/dev/null | head
find /media/internal/jihad -iname '*adapter*' 2>/dev/null | head
echo "=== does deployed adapter contain the [hp] log string? ==="
for f in $(find /media/internal/jihad -name '*.so' 2>/dev/null); do
  if strings "$f" 2>/dev/null | grep -q '\[hp\] dstRowBytes'; then echo "HAS-HP-LOG: $f"; else echo "no-hp-log: $f"; fi
done
