#!/bin/sh
echo "=== BrowserAdapter .so locations ==="
ls -la /media/internal/jihad/*.so 2>/dev/null
ls -la /media/internal/jihad/hl/*.so 2>/dev/null | head
find /media/cryptofs/apps/usr/palm/applications -iname '*dapter*.so' 2>/dev/null | head
find /var/palm/ljs* /usr/palm -iname 'BrowserAdapter*.so' 2>/dev/null | head
echo "=== plugin dir ==="; ls /media/internal/jihad/plugin* 2>/dev/null; find /media/internal/jihad -maxdepth 2 -name '*.so' 2>/dev/null
