#!/bin/sh
md5sum /media/internal/jihad/BrowserAdapterJihad.so 2>/dev/null
ls -la /media/internal/jihad/BrowserAdapterJihad.so 2>/dev/null
