#!/bin/sh
echo "device-now:"; md5sum /media/internal/jihad/BrowserAdapterJihad.so
chmod 777 /media/internal/jihad/BrowserAdapterJihad.so
