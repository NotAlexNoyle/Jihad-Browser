#!/bin/sh
D=/media/internal/jihad
echo "=== recent clickAt + navigate + nav result ==="
grep -aiE 'clickAt \(|clickAt -> navigate|load done uri=http' "$D/upstart-daemon.log" 2>/dev/null | tail -8
echo "=== final URL ==="; grep -a 'load done uri=' "$D/upstart-daemon.log" 2>/dev/null | tail -1 | cut -c1-60
echo "=== state: cards/daemon/load ==="
echo " cards:$(luna-send -n 1 palm://com.palm.applicationManager/running '{}' 2>/dev/null | grep -c jihad) daemon:$(ps -ef|grep -c '[j]ihad-browserserver') load:$(cut -d' ' -f1 /proc/loadavg)"
