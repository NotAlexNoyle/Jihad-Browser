#!/bin/sh
A=/media/cryptofs/apps/usr/palm/applications/net.riverstonerelay.jihad-browser
echo "=== index.html ==="
cat "$A/index.html" 2>/dev/null
echo "=== app root listing ==="
ls "$A" | tr '\n' ' '; echo
echo "=== any built/minified bundle? ==="
find "$A" -maxdepth 2 -name '*.js' 2>/dev/null | grep -iE 'built|deploy|min|package|app\.js' | head
echo "=== does enyo-1.0 exist next to app (../enyo-1.0)? ==="
ls -d "$A/../enyo-1.0" 2>/dev/null && ls "$A/../enyo-1.0/framework/enyo.js" 2>/dev/null || echo " NO ../enyo-1.0"
echo "=== is BasicWebView the kind name in system enyo? ==="
grep -rl 'name:.*BasicWebView\|BasicWebView' /usr/palm/frameworks/enyo/ 2>/dev/null | head -2
