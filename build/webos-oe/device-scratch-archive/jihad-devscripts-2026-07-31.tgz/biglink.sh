#!/bin/sh
D=/media/internal/jihad
CP=$(luna-send -n 1 palm://com.palm.applicationManager/running '{}' 2>/dev/null | sed 's/},{/}\n{/g' | grep -i jihad | grep -oiE 'processid[": ]+[0-9]+' | grep -oE '[0-9]+' | head -1)
[ -n "$CP" ] && luna-send -n 1 palm://com.palm.applicationManager/close "{\"processId\":\"$CP\"}" 2>/dev/null >/dev/null
sleep 2
# full-viewport link (steelblue): any tap hits <A>; navigates to example.net if activation works
luna-send -n 1 palm://com.palm.applicationManager/launch '{"id":"net.riverstonerelay.jihad-browser","params":{"target":"data:text/html,<body style=margin:0><a href=http://example.net/ style=display:block;height:100vh;background:steelblue>TAP</a>"}}' 2>&1 | head -1
sleep 9
echo "=== loaded? ==="
tail -6 "$D/upstart-daemon.log" 2>/dev/null | grep -aiE 'openUrl|load done|painted bytes'
