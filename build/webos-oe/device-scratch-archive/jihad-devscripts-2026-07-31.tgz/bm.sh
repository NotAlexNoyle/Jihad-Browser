#!/bin/sh
luna-send -n 1 -a net.riverstonerelay.jihad-browser luna://com.palm.db/put "{\"objects\":[{\"_kind\":\"net.riverstonerelay.jihad-browser.bookmarks:1\",\"url\":\"http://bmtest/\",\"title\":\"BM\",\"idx\":0}]}"
luna-send -n 1 -a net.riverstonerelay.jihad-browser luna://com.palm.db/find "{\"query\":{\"from\":\"net.riverstonerelay.jihad-browser.bookmarks:1\"}}"
