#!/bin/sh
luna-send -n 1 -a net.riverstonerelay.jihad-browser luna://com.palm.db/put '{"objects":[{"_kind":"net.riverstonerelay.jihad-browser.bookmarks:1","title":"AppShaped","url":"http://appshaped/","date":1,"lastVisited":1,"defaultEntry":false,"visitCount":0,"idx":null}]}'
echo "--- find orderBy idx ---"
luna-send -n 1 -a net.riverstonerelay.jihad-browser luna://com.palm.db/find '{"query":{"from":"net.riverstonerelay.jihad-browser.bookmarks:1","orderBy":"idx"}}'
