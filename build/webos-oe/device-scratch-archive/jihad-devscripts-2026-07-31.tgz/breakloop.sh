#!/bin/sh
D=/media/internal/jihad
# who is the daemon's parent (the respawner)?
DPID=$(ps -ef | grep '[l]d-2.23.so' | awk '{print $2}' | head -1)
PPID=$(ps -ef | awk -v P="$DPID" '$2==P{print $3}')
echo "daemon pid=$DPID parent=$PPID ($(ps -ef | awk -v P="$PPID" '$2==P{for(i=8;i<=NF;i++)printf \"%s \",$i}'))"
# break the exec loop: move the binary aside so respawn fails cleanly
mv "$D/hl/jihad-browserserver" "$D/hl/jihad-browserserver.OFF" 2>/dev/null && echo "binary moved aside"
# stop respawners
/sbin/stop browserserver 2>/dev/null
rm -f "$D/keepalive.on"; /usr/bin/pkill -9 -f keepalive.sh 2>/dev/null
/usr/bin/pkill -9 minicore2 2>/dev/null
/usr/bin/pkill -9 -f jihad-browserserver 2>/dev/null
sleep 4
echo "loadavg: $(cat /proc/loadavg | cut -d' ' -f1-3)"
echo "daemon: $(ps -ef | grep -c '[l]d-2.23.so')  minicore2: $(ps -ef | grep -c '[m]inicore2')"
