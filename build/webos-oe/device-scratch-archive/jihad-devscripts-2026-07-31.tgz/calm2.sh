#!/bin/sh
D=/media/internal/jihad
# close all jihad cards
for r in 1 2; do
  for p in $(luna-send -n 1 palm://com.palm.applicationManager/running '{}' 2>/dev/null | tr ',' '\n' | grep -oE '"processId":"[0-9]+"' | grep -oE '[0-9]+'); do
    luna-send -n 1 palm://com.palm.applicationManager/close "{\"processId\":\"$p\"}" 2>/dev/null; done
  sleep 2
done
# restart daemon to a clean idle (upstart respawns it)
/sbin/stop browserserver 2>/dev/null; sleep 1; : > "$D/upstart-daemon.log"; /sbin/start browserserver 2>/dev/null | tail -1
sleep 3
echo "cards: $(luna-send -n 1 palm://com.palm.applicationManager/running '{}' 2>/dev/null | grep -oc jihad-browser)"
echo "daemon serving: $(grep -c 'serving YAP' "$D/upstart-daemon.log")"
echo "loadavg: $(cat /proc/loadavg | cut -d' ' -f1-3)"
