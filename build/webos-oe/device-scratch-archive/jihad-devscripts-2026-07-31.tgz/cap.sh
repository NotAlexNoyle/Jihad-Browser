#!/bin/sh
D=/media/internal/jihad
dd if=/dev/fb1 of=$D/capnow.bgra bs=4096 count=768 2>/dev/null
echo "daemon last paints:"; grep -a painted $D/upstart-daemon.log | tail -3
echo "adapter last hp:"; grep -a '\[hp\]' $D/adapter.log | tail -2
