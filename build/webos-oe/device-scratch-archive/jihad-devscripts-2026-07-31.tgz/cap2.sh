#!/bin/sh
echo "fb0 virtual_size: $(cat /sys/class/graphics/fb0/virtual_size 2>/dev/null)"
echo "fb0 stride/bpp: $(cat /sys/class/graphics/fb0/stride 2>/dev/null) / $(cat /sys/class/graphics/fb0/bits_per_pixel 2>/dev/null)"
dd if=/dev/fb0 of=/media/internal/jihad/screen.bgra bs=4096 count=1024 2>/dev/null
echo "captured $(wc -c < /media/internal/jihad/screen.bgra) bytes"
echo "loadavg: $(cut -d' ' -f1-3 /proc/loadavg)"
echo "daemon CPU%: $(ps -eo pcpu,comm 2>/dev/null | grep jihad-browser | awk '{print $1}' | head -1)"
