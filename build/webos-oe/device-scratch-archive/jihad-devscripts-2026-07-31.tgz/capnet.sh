#!/bin/sh
dd if=/dev/fb1 of=/media/internal/jihad/fb1net.bgra bs=4096 count=768 2>/dev/null
echo "captured $(wc -c < /media/internal/jihad/fb1net.bgra) bytes; url=$(grep -a 'load done uri=' /media/internal/jihad/upstart-daemon.log 2>/dev/null | tail -1 | cut -c1-45)"
