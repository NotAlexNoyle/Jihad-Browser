#!/bin/sh
dd if=/dev/fb1 of=/media/internal/jihad/fb1r.bgra bs=4096 count=768 2>/dev/null
echo "captured $(wc -c < /media/internal/jihad/fb1r.bgra) bytes"
