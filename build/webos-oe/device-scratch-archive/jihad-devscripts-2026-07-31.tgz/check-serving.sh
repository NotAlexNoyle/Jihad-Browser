#!/bin/sh
echo "=== yap socket (daemon serving if present) ==="
ls -la /tmp/yapserver.browser 2>/dev/null || echo "NO socket"
echo "=== daemon proc + its cmdline ==="
P=$(ps -ef | grep '[j]ihad-browserserver' | awk '{print $2}' | head -1)
echo "pid=$P"
[ -n "$P" ] && cat /proc/$P/cmdline 2>/dev/null | tr '\0' ' '; echo
echo "=== where is stdout going (fd 1) ==="
[ -n "$P" ] && ls -la /proc/$P/fd/1 2>/dev/null
echo "=== daemon output in /var/log/messages? ==="
grep -a 'jihad-bs' /var/log/messages 2>/dev/null | tail -3
