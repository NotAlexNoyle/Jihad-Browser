#!/bin/sh
sleep 18
echo "== daemon proc alive? =="; ps -ef 2>/dev/null | grep jihad-browserserver | grep -v grep | head -1
echo "== yapserver.browser mtime (rebound = fresh) =="; ls -la /tmp/yapserver.browser 2>&1
echo "== daemon log (non-fontconfig) =="; grep -vE 'Fontconfig warning' /media/internal/jihad/browser-d.log 2>/dev/null | tail -12
