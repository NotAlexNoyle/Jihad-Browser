#!/bin/sh
D=/media/internal/jihad
echo "=== recent: taps + vkb diag + editorFocused + titleAndUrl + paints ==="
grep -aiE 'clickAt \(|vkb |editorFocused|titleAndUrl|painted .*bytes|load done uri=|content-nav' "$D/upstart-daemon.log" 2>/dev/null | tail -25
echo "=== paint activity: are painted bytes>0 (rendering) or 0 (black)? ==="
grep -a 'painted' "$D/upstart-daemon.log" 2>/dev/null | tail -4
echo "=== state ==="
echo "daemon:$(ps -ef|grep -c '[j]ihad-browserserver') card:$(luna-send -n 1 palm://com.palm.applicationManager/running '{}' 2>/dev/null|grep -c jihad) load:$(cut -d' ' -f1-3 /proc/loadavg)"
