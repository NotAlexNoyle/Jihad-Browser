#!/bin/sh
echo "=== search logs for override marker [Jihad] + BrowserApp load ==="
for f in /var/log/messages /var/log/messages.0 /media/internal/jihad/*.log; do
  [ -f "$f" ] && grep -l 'Jihad\] WebView\|x-jihad-browser\|BrowserApp' "$f" 2>/dev/null
done
echo "--- grep messages for jihad app console ---"
grep -iE '\[Jihad\]|jihad-browser|BrowserApp' /var/log/messages 2>/dev/null | tail -15
echo "=== does the app dir have a WebKit cache / appcache manifest ==="
find /var/luna /var/palm -iname '*.cache' -path '*jihad*' 2>/dev/null | head
ls -la /media/cryptofs/apps/usr/palm/applications/net.riverstonerelay.jihad-browser/source/JihadEngineOverride.js 2>/dev/null | awk '{print " override on device:",$5,"bytes"}'
