#!/bin/sh
D=/media/internal/jihad
echo "=== hit-test + navigation after your taps ==="
grep -aiE 'clickAt hittest|openUrl|load done uri=|state top.*START|loaderr' "$D/upstart-daemon.log" 2>/dev/null | tail -18
echo "=== current URL loaded (did it leave example.com?) ==="
grep -a 'load done uri=' "$D/upstart-daemon.log" 2>/dev/null | tail -1
