#!/bin/sh
D=/media/internal/jihad
# same pid after a few seconds == not respawn-crashing
P1=$(ps -ef 2>/dev/null | grep '[j]ihad-browserserver' | awk '{print $2}' | head -1)
sleep 5
P2=$(ps -ef 2>/dev/null | grep '[j]ihad-browserserver' | awk '{print $2}' | head -1)
echo "daemon pid: first=$P1 after5s=$P2 $( [ -n "$P1" ] && [ "$P1" = "$P2" ] && echo STABLE || echo RESPAWNING/DEAD )"
echo "jihad socket: $(ls /tmp/yapserver.jihad-browser 2>/dev/null || echo NONE)"
echo "loadavg: $(cut -d' ' -f1-3 /proc/loadavg)"
echo "=== daemon startup log (last 15) ==="
tail -15 "$D/upstart-daemon.log" 2>/dev/null
