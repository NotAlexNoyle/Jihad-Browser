#!/bin/sh
echo "=== profile dir (browser-services R2 persistence) ==="
find /media/internal/jihad -maxdepth 2 -name "cookies.sqlite" 2>/dev/null
ls -la /media/internal/jihad/profile 2>/dev/null | head
echo "=== JIHAD_PROFILE_DIR in upstart job? ==="
grep -o "JIHAD_PROFILE_DIR=[^ ]*" /etc/event.d/jihad 2>/dev/null || echo "(not set in job)"
