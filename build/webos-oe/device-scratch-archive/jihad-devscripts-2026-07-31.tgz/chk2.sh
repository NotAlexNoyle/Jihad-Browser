#!/bin/sh
echo "== daemon log now (any connection?) =="
grep -vE 'Fontconfig warning' /media/internal/jihad/integ-d.log 2>/dev/null | tail -12
echo "== does our adapter.so resolve its deps on device? (ldd) =="
ldd /usr/lib/BrowserPlugins/BrowserAdapter.so 2>&1 | grep -iE 'not found|=>' | head -20
echo "== is a Jihad browser card running? =="
ps -ef 2>/dev/null | grep -iE 'jihad|BrowserAdapter|WebAppMgr|browser' | grep -v grep | head
echo "== recent luna/sysmgr errors about plugin/adapter =="
ls -la /var/log/messages 2>/dev/null; tail -30 /var/log/messages 2>/dev/null | grep -iE 'adapter|plugin|browser|npapi|jihad' | tail -10
