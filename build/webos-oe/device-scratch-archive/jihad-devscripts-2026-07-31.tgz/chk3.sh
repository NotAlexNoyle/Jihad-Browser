#!/bin/sh
echo "== tail of /var/log/messages (WebAppMgr / plugin / adapter / crash) =="
tail -80 /var/log/messages 2>/dev/null | grep -iE 'adapter|plugin|npapi|webapp|WebKit|crash|segv|jihad|riverstone|BrowserServer|luna-send|applicationManager' | tail -25
echo "== is LunaSysMgr / WebAppMgr alive? =="
ps -ef 2>/dev/null | grep -iE 'LunaSysMgr|WebAppMgr|MojoApp|sysmgr' | grep -v grep | head
echo "== relaunch app + immediately watch for adapter/plugin load in messages =="
/usr/bin/luna-send -n 1 palm://com.palm.applicationManager/launch '{"id":"net.riverstonerelay.jihad","params":{"target":"http://example.com/"}}' 2>&1
sleep 12
echo "-- new messages since launch --"
tail -40 /var/log/messages 2>/dev/null | grep -iE 'adapter|plugin|npapi|jihad|riverstone|error|fail|BrowserAdapter' | tail -15
echo "-- daemon connection? --"; grep -c 'client connected' /media/internal/jihad/integ-d.log
