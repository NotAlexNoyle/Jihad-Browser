#!/bin/sh
echo "=== profile after loading a site ==="
ls -la /media/internal/jihad/profile/ 2>/dev/null
find /media/internal/jihad/profile -name "*.sqlite" 2>/dev/null
