#!/bin/sh
RESP=$(/usr/bin/luna-send -n 1 palm://com.palm.applicationManager/running '{}' 2>/dev/null)
PIDS=$(echo "$RESP" | tr '}' '\n' | grep 'net.riverstonerelay.jihad-browser' | grep -oE '"processid":"[0-9]+"' | grep -oE '[0-9]+')
for p in $PIDS; do /usr/bin/luna-send -n 1 palm://com.palm.applicationManager/close "{\"processId\":\"$p\"}" 2>/dev/null; done
sleep 3
/sbin/stop browserserver 2>/dev/null; /usr/bin/pkill -9 -f jihad-browserserver 2>/dev/null; sleep 1; rm -f /tmp/yapserver.browser*
rm -f /media/internal/jihad/integ-d.log
# LD_LIBRARY_PATH scoped to the daemon ONLY (bundled gcc9 libstdc++ must NOT leak to luna-send)
( cd /media/internal/jihad/hl
  export JIHAD_OFFSCREEN=1 JIHAD_DISABLE_OMTC=1 FONTCONFIG_PATH=/etc/fonts JIHAD_BS_NAME=browser
  export LD_LIBRARY_PATH=/media/internal/jihad/hl JIHAD_DUMP=/media/internal/jihad/frame.ppm
  ./ld-2.23.so --library-path /media/internal/jihad/hl ./jihad-browserserver /media/internal/jihad/hl >/media/internal/jihad/integ-d.log 2>&1 & ) &
i=0; while [ $i -lt 45 ]; do grep -q "serving YAP 'browser'" /media/internal/jihad/integ-d.log 2>/dev/null && break; sleep 1; i=$((i+1)); done
echo "daemon serving after ${i}s"; sleep 2
/usr/bin/luna-send -n 1 palm://com.palm.applicationManager/launch '{"id":"net.riverstonerelay.jihad-browser","params":{"target":"data:text/html,<body style=\"font-size:20px;font-family:sans-serif\">UA:<br><b id=x></b><script>document.getElementById(\"x\").textContent=navigator.userAgent</script></body>"}}'
