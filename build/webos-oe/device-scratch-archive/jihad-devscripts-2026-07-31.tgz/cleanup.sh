rm -f /media/internal/jihad/keyprobe /media/internal/jihad/keyprobe.log
rm -f /media/internal/jihad/hl/jihad-browserserver-probe
rm -f /media/internal/jihad/runprobe.sh /media/internal/jihad/dumpkeys.sh /media/internal/jihad/rawkeys.sh /media/internal/jihad/setflag.sh /media/internal/jihad/clr.sh /media/internal/jihad/dlog.sh /media/internal/jihad/md5.sh
echo CLEANED
