#!/bin/sh
D=/media/internal/jihad
/sbin/stop browserserver 2>/dev/null; /usr/bin/pkill -9 -f jihad-browserserver 2>/dev/null; sleep 2
rm -f /tmp/yapserver.browser*
/sbin/start browserserver 2>&1 | tail -1
sleep 3
P1=$(ps -ef | grep '[l]d-2.23.so' | awk '{print $2}' | head -1)
sleep 5
P2=$(ps -ef | grep '[l]d-2.23.so' | awk '{print $2}' | head -1)
echo "pid t=3s: $P1 ; pid t=8s: $P2"
[ -n "$P1" ] && [ "$P1" = "$P2" ] && echo "STABLE under upstart" || echo "UNSTABLE (crash-looping)"
echo "instances: $(ps -ef | grep -c '[l]d-2.23.so')"
echo "socket: $(ls /tmp/yapserver.browser 2>/dev/null && echo present)"
