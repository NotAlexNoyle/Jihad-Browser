#!/bin/sh
ls -t /var/log/messages* 2>/dev/null | head -1
tail -40 /var/log/messages 2>/dev/null | grep -iE 'BrowserAdapter|LunaSysMgr|segv|crash|signal|abort|jihad' | tail -8
