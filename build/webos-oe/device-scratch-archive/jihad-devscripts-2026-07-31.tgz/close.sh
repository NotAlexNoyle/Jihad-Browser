#!/bin/sh
luna-send -n 1 palm://com.palm.applicationManager/listRunningApps '{}' >/dev/null 2>&1
# close by app id via the card manager
luna-send -n 1 palm://com.palm.applicationManager/closeByProcessId '{"id":"net.riverstonerelay.jihad-browser.mochi"}' >/dev/null 2>&1
