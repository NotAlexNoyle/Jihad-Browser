#!/bin/sh
for p in $(luna-send -n 1 palm://com.palm.applicationManager/running '{}' 2>/dev/null | tr ',' '\n' | grep -oE '"processId":"[0-9]+"' | grep -oE '[0-9]+'); do
  luna-send -n 1 palm://com.palm.applicationManager/close "{\"processId\":\"$p\"}" 2>/dev/null; done
echo "closed cards; loadavg: $(cat /proc/loadavg | cut -d' ' -f1-3)"
