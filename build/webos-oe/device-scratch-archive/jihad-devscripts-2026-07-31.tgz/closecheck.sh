#!/bin/sh
echo "=== close jihad card ==="
luna-send -n 1 palm://com.palm.applicationManager/close '{"id":"net.riverstonerelay.jihad-browser"}' 2>/dev/null | head -1
# also kill any jihad card process by app id (best-effort)
sleep 3
echo "=== top CPU consumers ==="
ps -eo pid,pcpu,comm 2>/dev/null | sort -k2 -rn | head -8
echo "=== sockets/procs ==="
echo " stock BS: $(ps -ef 2>/dev/null | grep -c '[/]usr/bin/BrowserServer')  jihad: $(ps -ef 2>/dev/null | grep -c '[j]ihad-browserserver')"
echo " stock sock: $(ls /tmp/yapserver.browser 2>/dev/null || echo NONE)  jihad sock: $(ls /tmp/yapserver.jihad-browser 2>/dev/null || echo NONE)"
echo " jihad card: $(luna-send -n 1 palm://com.palm.applicationManager/running '{}' 2>/dev/null | grep -c jihad)"
echo " loadavg: $(cut -d' ' -f1-3 /proc/loadavg)"
