#!/bin/sh
luna-send -n 1 -a net.riverstonerelay.jihad-browser luna://com.palm.db/del "{\"query\":{\"from\":\"net.riverstonerelay.jihad-browser.history:1\"}}"
