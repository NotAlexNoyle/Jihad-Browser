#!/bin/sh
D=/media/internal/jihad
: > $D/adapter.log
# reload blue page fresh
luna-send -n 1 palm://com.palm.applicationManager/launch '{"id":"net.riverstonerelay.jihad-browser","params":{"target":"data:text/html,<meta name=viewport content=width=device-width><body style=background:%23bbddff;font-size:40px;padding:30px>Tap box, then type:<br><br><input style=font-size:36px;width:85%25;padding:12px;background:white></body>"}}' 2>/dev/null >/dev/null
echo "reloaded. WAITING for editorFocused (tap the box now)..."
# poll daemon log for editorFocused
i=0; seen=0
while [ $i -lt 22 ]; do
  sleep 4
  tail -30 $D/upstart-daemon.log | grep -a 'editorFocused=1' >/dev/null && seen=1
  [ $seen -eq 1 ] && break
  i=$((i+1))
done
echo "editorFocused seen=$seen; waiting 5s for white to settle..."
sleep 5
dd if=/dev/fb1 of=$D/fbcorr.bgra bs=4096 count=768 2>/dev/null
echo "=== daemon last 8 paints/geometry ==="
grep -aiE 'painted|emitGeometry|setWindowSize' $D/upstart-daemon.log | tail -8
echo "=== adapter [hp] ALL (since truncate) ==="
grep -a '\[hp\]' $D/adapter.log
echo "=== daemon pid ==="; ps -ef|grep '[j]ihad-browserserver'|awk '{print $2}'|head -1
