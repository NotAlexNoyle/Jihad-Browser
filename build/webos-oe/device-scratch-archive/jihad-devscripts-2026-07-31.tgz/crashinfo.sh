#!/bin/sh
D=/media/internal/jihad
echo "=== daemon log around crash (last 40, look for signal/assert/InsertText) ==="
tail -40 $D/upstart-daemon.log
echo "=== cores ==="
ls -la /media/internal/jihad/core* /var/log/core* 2>/dev/null | head
ls -la core* 2>/dev/null | head
