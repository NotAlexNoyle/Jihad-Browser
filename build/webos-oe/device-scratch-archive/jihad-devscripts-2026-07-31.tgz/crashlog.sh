echo "=== daemon log tail (crash context) ==="
tail -30 /media/internal/jihad/upstart-daemon.log 2>/dev/null
