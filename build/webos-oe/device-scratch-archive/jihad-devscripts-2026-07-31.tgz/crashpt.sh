#!/bin/sh
D=/media/internal/jihad
echo "=== daemon log around restarts (engine up = respawn after crash) ==="
grep -anE 'engine up|engine init|clickAt \(.*<(INPUT|TEXTAREA)>|vkb |Segmentation|Assertion|MOZ_|abort' "$D/upstart-daemon.log" 2>/dev/null | tail -18
echo "=== count of daemon respawns (engine up lines) ==="
grep -c 'engine up' "$D/upstart-daemon.log" 2>/dev/null
echo "=== any core dumps? ==="
ls -la /media/internal/jihad/core* /tmp/core* 2>/dev/null | head; ls /media/internal/*.core 2>/dev/null | head
