#!/bin/sh
D=/media/internal/jihad
/sbin/stop browserserver 2>/dev/null; /usr/bin/pkill -9 -f jihad-browserserver 2>/dev/null; sleep 2
# mimic upstart: minimal env (env -i), same as the job
cd "$D/hl"
env -i LD_LIBRARY_PATH="$D/hl" JIHAD_DUMP="$D/frame.ppm" JIHAD_BS_NAME=browser JIHAD_OFFSCREEN=1 JIHAD_DISABLE_OMTC=1 \
  ./ld-2.23.so --library-path "$D/hl" ./jihad-browserserver "$D/hl" >"$D/crash.log" 2>&1 &
DPID=$!
sleep 4
echo "alive after 4s: $(kill -0 $DPID 2>/dev/null && echo yes || echo NO-crashed)"
echo "=== crash.log (minimal env) ==="
grep -viE 'Fontconfig' "$D/crash.log" | tail -12
kill -9 $DPID 2>/dev/null
