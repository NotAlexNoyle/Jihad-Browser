#!/bin/sh
echo "=== top CPU processes ==="
ps -ef 2>/dev/null | sort -k4 -rn 2>/dev/null | head -6 | awk '{print $2, $4, $NF}'
echo "=== jihad daemon paint rate (looping render?) ==="
echo "paints in log: $(grep -c painted /media/internal/jihad/upstart-daemon.log)"
echo "daemon instances: $(ps -ef | grep -c '[l]d-2.23.so')"
echo "jihad cards: $(luna-send -n 1 palm://com.palm.applicationManager/running '{}' 2>/dev/null | grep -oc 'jihad-browser')"
