#!/bin/sh
md5sum /media/internal/jihad/hl/libxul.so 2>/dev/null | cut -c1-12
ls -la /media/internal/jihad/hl/libxul.so 2>/dev/null | awk '{print $5}'
