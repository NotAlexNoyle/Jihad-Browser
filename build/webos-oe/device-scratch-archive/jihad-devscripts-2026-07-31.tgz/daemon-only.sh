#!/bin/sh
/usr/bin/pkill -9 -f jihad-browserserver 2>/dev/null; sleep 2; rm -f /tmp/yapserver.browser*
rm -f /media/internal/jihad/integ-d.log /media/internal/jihad/frame.ppm /media/internal/jihad/adapter.log
( cd /media/internal/jihad/hl
  export LD_LIBRARY_PATH=/media/internal/jihad/hl JIHAD_DUMP=/media/internal/jihad/frame.ppm JIHAD_BS_NAME=browser JIHAD_OFFSCREEN=1 JIHAD_DISABLE_OMTC=1
  ./ld-2.23.so --library-path /media/internal/jihad/hl ./jihad-browserserver /media/internal/jihad/hl >/media/internal/jihad/integ-d.log 2>&1 & ) &
i=0; while [ $i -lt 30 ]; do grep -q "serving YAP 'browser'" /media/internal/jihad/integ-d.log 2>/dev/null && break; sleep 1; i=$((i+1)); done
echo "fresh daemon serving after ${i}s (waiting for a card; none launched)"
