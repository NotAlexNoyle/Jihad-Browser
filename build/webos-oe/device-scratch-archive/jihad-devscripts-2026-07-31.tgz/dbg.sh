grep -aE "vkb|clickAt|editorFocused|duckduckgo|google|load done|openUrl|0x804b0003" /media/internal/jihad/upstart-daemon.log 2>/dev/null | tail -45
