#!/bin/sh
D=/media/internal/jihad
rm -f "$D/keepalive.on"; /usr/bin/pkill -9 -f keepalive.sh 2>/dev/null; /usr/bin/pkill -9 -f jihad-browserserver 2>/dev/null
sleep 2; : > "$D/keepalive-sup.log"
# start supervisor in background WITHIN this session
sh "$D/keepalive.sh" >>"$D/keepalive-sup.log" 2>&1 &
SUPPID=$!
sleep 4
echo "supervisor pid=$SUPPID alive=$(kill -0 $SUPPID 2>/dev/null && echo yes || echo no)"
echo "keepalive.on: $([ -f "$D/keepalive.on" ] && echo yes || echo no)"
echo "daemon running: $(ps -ef | grep -c '[j]ihad-browserserver')"
echo "sup-log:"; cat "$D/keepalive-sup.log" | tail -5
echo "daemon-log tail:"; grep -viE 'Fontconfig' "$D/integ-d.log" | tail -3
