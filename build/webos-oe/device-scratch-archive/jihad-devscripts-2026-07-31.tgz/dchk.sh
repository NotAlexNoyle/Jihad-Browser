#!/bin/sh
tail -20 /media/internal/jihad/upstart-daemon.log | grep -aE 'insertStr|keyDown|editorFocused|InsertText' | tail -10
