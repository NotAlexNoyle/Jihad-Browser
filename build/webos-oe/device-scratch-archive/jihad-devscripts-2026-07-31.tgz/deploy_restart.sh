#!/bin/sh
D=/media/internal/jihad
echo "device md5:"; md5sum $D/BrowserAdapterJihad.so
chmod 777 $D/BrowserAdapterJihad.so
: > $D/adapter.log
echo "restarting LunaSysMgr..."; killall LunaSysMgr 2>/dev/null
i=0; while [ $i -lt 30 ]; do sleep 3; NP=$(pidof LunaSysMgr); [ -n "$NP" ] && break; i=$((i+1)); done
echo "LunaSysMgr up: $NP"
