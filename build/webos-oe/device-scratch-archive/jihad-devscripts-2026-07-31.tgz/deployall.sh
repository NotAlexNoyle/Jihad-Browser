#!/bin/sh
D=/media/internal/jihad
APP=/media/cryptofs/apps/usr/palm/applications/net.riverstonerelay.jihad-browser
# verify staged pushes
echo "staged: daemon=$(md5sum $D/hl/jihad-browserserver|cut -c1-12) impl=$(md5sum $D/BrowserAdapterImpl.so.new|cut -c1-12) shim=$(md5sum $D/BrowserAdapterJihad.so.new|cut -c1-12)"
chmod 755 $D/hl/jihad-browserserver
# impl -> app bundle (trusted) + jihad dir (dev)
cp $D/BrowserAdapterImpl.so.new $APP/BrowserAdapterImpl.so && cp $D/BrowserAdapterImpl.so.new $D/BrowserAdapterImpl.so
chmod 755 $APP/BrowserAdapterImpl.so $D/BrowserAdapterImpl.so
# dev marker so the shim will use the fast /media/internal iteration path
touch $D/DEV
# shim -> system plugin dir
mount -o remount,rw / 2>/dev/null
cp $D/BrowserAdapterJihad.so.new /usr/lib/BrowserPlugins/BrowserAdapterJihad.so
chmod 755 /usr/lib/BrowserPlugins/BrowserAdapterJihad.so
sync
echo "installed: appimpl=$(md5sum $APP/BrowserAdapterImpl.so|cut -c1-12) shim=$(md5sum /usr/lib/BrowserPlugins/BrowserAdapterJihad.so|cut -c1-12)"
# restart daemon
/sbin/stop jihad 2>/dev/null; sleep 2; /sbin/start jihad 2>/dev/null; sleep 3
echo "daemon pid: $(ps -ef|grep '[j]ihad-browserserver'|awk '{print $2}'|head -1)"
# restart LunaSysMgr to load the new shim
: > $D/shim.log; : > $D/adapter.log
killall LunaSysMgr 2>/dev/null
i=0; while [ $i -lt 30 ]; do sleep 3; NP=$(pidof LunaSysMgr); [ -n "$NP" ] && break; i=$((i+1)); done
echo "luna up: $NP"
