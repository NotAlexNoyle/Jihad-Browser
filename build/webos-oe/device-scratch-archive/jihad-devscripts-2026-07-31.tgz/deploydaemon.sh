#!/bin/sh
D=/media/internal/jihad
echo "device daemon md5: $(md5sum $D/hl/jihad-browserserver | cut -c1-12)"
chmod 755 $D/hl/jihad-browserserver
/sbin/stop jihad 2>/dev/null; sleep 2; /sbin/start jihad 2>/dev/null; sleep 4
echo "daemon pid: $(ps -ef|grep '[j]ihad-browserserver'|awk '{print $2}'|head -1)"
