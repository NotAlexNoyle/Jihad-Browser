#!/bin/sh
echo "loadavg: $(cat /proc/loadavg 2>/dev/null)"
echo "daemon instances: $(ps -ef | grep -c '[l]d-2.23.so')"
echo "daemon respawns (serving count): $(grep -c 'serving YAP' /media/internal/jihad/upstart-daemon.log 2>/dev/null)"
echo "jihad cards open: $(luna-send -n 1 palm://com.palm.applicationManager/running '{}' 2>/dev/null | grep -oc '"id":"net.riverstonerelay.jihad-browser"')"
