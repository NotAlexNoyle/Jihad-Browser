#!/bin/sh
echo "=== upstart job = jihad or stock? ==="
grep -c 'jihad-browserserver' /etc/event.d/browserserver 2>/dev/null && echo "(jihad job present)" || echo "(stock or missing)"
echo "=== what owns the yap socket / is BrowserServer running ==="
ps -ef | grep -iE 'BrowserServer|jihad-browserserver' | grep -v grep | head
echo "=== top CPU (what's loading it) ==="
ps -ef 2>/dev/null | sort -k4 -rn 2>/dev/null | head -5 | awk '{print $2, $NF}'
echo "=== deployed daemon md5 (matches my vetted build?) ==="
/usr/bin/md5sum /media/internal/jihad/hl/jihad-browserserver 2>/dev/null
