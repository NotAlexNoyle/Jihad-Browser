#!/bin/sh
cd /media/internal/jihad/goanna
chmod 755 ld-2.23.so jihad-browserserver 2>/dev/null
export JIHAD_OFFSCREEN=1
export JIHAD_DISABLE_OMTC=1
export FONTCONFIG_PATH=/etc/fonts
./ld-2.23.so --library-path /media/internal/jihad/goanna ./jihad-browserserver /media/internal/jihad/goanna >/media/internal/jihad/out.log 2>&1 &
P=$!
sleep 10
kill $P 2>/dev/null
echo "=== daemon output (device) ==="
cat /media/internal/jihad/out.log
