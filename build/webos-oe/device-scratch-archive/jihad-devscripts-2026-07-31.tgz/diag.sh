#!/bin/sh
echo "=== all WebAppMgr / webkit / browser procs ==="
ps -ef 2>/dev/null | grep -iE 'webappmgr|webkit|browser|sysmgr' | grep -v grep
echo "=== WebAppMgr open sockets (what is it connecting to) ==="
WPID=$(ps -ef 2>/dev/null | grep '[W]ebAppMgr' | awk '{print $2}' | head -1)
echo "WebAppMgr pid=$WPID"
ls -l /proc/$WPID/fd 2>/dev/null | grep -iE 'yapserver|socket|browser' | head
echo "=== yapserver sockets present ==="
ls -la /tmp/yapserver.* 2>/dev/null
echo "=== stock BrowserServer: pid + age ==="
ps -eo pid,etime,comm 2>/dev/null | grep -i browserserver
echo "=== is stock BS actually listening? ==="
ps -ef 2>/dev/null | grep '[/]usr/bin/BrowserServer'
