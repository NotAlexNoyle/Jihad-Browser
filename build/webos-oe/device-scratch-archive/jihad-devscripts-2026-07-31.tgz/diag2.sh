#!/bin/sh
L=/media/internal/jihad/upstart-daemon.log
echo "=== clickAt received by daemon? (single-tap fix working?) ==="
grep -c 'clickAt' "$L" 2>/dev/null
grep 'clickAt' "$L" 2>/dev/null | tail -3
echo "=== whatismybrowser: openUrl + load done + errors ==="
grep -iE 'openUrl whatismy|load done uri=http|loaderr failed=1|loaderr.*code=0x[1-9a-f]' "$L" 2>/dev/null | tail -5
echo "=== whatismybrowser paints (did it render anything)? ==="
grep 'painted' "$L" 2>/dev/null | tail -4
echo "=== adapter LANDSCAPE geometry (logged on dim change) ==="
grep hp /media/internal/jihad/adapter.log 2>/dev/null | tail -4
