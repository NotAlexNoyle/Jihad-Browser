#!/bin/sh
D=/media/internal/jihad
echo "=== running daemon md5 (expect 6ab011c...) + uptime + state ==="
echo " md5:$(md5sum $D/hl/jihad-browserserver 2>/dev/null|cut -d' ' -f1) daemon:$(ps -ef|grep -c '[j]ihad-browserserver') up:$(cut -d. -f1 /proc/uptime)s load:$(cut -d' ' -f1-3 /proc/loadavg)"
echo "=== did editorFocused EVER log? (full log) ==="
grep -a 'editorFocused' "$D/upstart-daemon.log" 2>/dev/null | tail -5 || echo " (no editorFocused lines at all)"
echo "=== INPUT taps + what followed (did ClickAt reach the editable block?) ==="
grep -aiE 'clickAt.*<INPUT>|editorFocused|content-nav re-drive' "$D/upstart-daemon.log" 2>/dev/null | tail -8
echo "=== adapter has the title-url + editor handlers? (deployed adapter) ==="
strings /usr/lib/BrowserPlugins/BrowserAdapterJihad.so 2>/dev/null | grep -iE 'titleChange|editorFocused|titleURL' | sort -u | head
