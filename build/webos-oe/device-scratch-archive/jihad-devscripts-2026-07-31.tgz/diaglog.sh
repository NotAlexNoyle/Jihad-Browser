grep -aE "clickAt|DIAG|navigate|openUrl|load done" /media/internal/jihad/upstart-daemon.log 2>/dev/null | tail -40
