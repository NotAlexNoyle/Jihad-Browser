#!/bin/sh
D=/media/internal/jihad
PID0=$(ps -ef|grep '[j]ihad-browserserver'|awk '{print $2}'|head -1)
MARK=$(wc -l < $D/upstart-daemon.log)
echo "tap + type now..."
i=0; seen=0
while [ $i -lt 26 ]; do
  sleep 4
  tail -30 $D/upstart-daemon.log | grep -aE 'insertStr|editorFocused=1' >/dev/null && seen=1
  [ $seen -eq 1 ] && break
  i=$((i+1))
done
sleep 10
PID1=$(ps -ef|grep '[j]ihad-browserserver'|awk '{print $2}'|head -1)
echo "daemon $PID0 -> $PID1 $([ "$PID0" = "$PID1" ] && echo STABLE || echo CRASHED)"
echo "=== insert diagnostic trace ==="
tail -n +$((MARK+1)) $D/upstart-daemon.log | grep -aE 'editorFocused|insertStr|InsertText|keyDown' | tail -20
