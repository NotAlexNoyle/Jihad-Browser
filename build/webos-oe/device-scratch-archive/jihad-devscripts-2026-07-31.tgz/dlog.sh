#!/bin/sh
tail -n +13034 /var/log/messages | grep -iE "mochi.*(Uncaught|Error|Exception|undefined|not a function|is not defined|TypeError)" | tail -8
