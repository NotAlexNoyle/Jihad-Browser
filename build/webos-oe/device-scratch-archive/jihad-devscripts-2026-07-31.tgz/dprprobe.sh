#!/bin/sh
P='{"id":"net.riverstonerelay.jihad-browser","params":{"target":"data:text/html,<body style=font-size:30px;font-family:sans-serif>DPR=<script>document.write(window.devicePixelRatio)</script><br>iw=<script>document.write(innerWidth)</script><br>ih=<script>document.write(innerHeight)</script></body>"}}'
n(){ luna-send -n 1 palm://com.palm.applicationManager/running '{}' 2>/dev/null | tr '}' '\n' | grep -c 'net.riverstonerelay.jihad-browser'; }
for p in $(luna-send -n 1 palm://com.palm.applicationManager/running '{}' 2>/dev/null | tr '}' '\n' | grep 'net.riverstonerelay.jihad-browser' | grep -oE '"processid":"[0-9]+"' | grep -oE '[0-9]+'); do luna-send -n 1 palm://com.palm.applicationManager/close "{\"processId\":\"$p\"}" 2>/dev/null; done
sleep 3
/usr/bin/pkill -9 -f jihad-browserserver 2>/dev/null; sleep 2; rm -f /tmp/yapserver.browser*
rm -f /media/internal/jihad/integ-d.log /media/internal/jihad/frame.ppm
( cd /media/internal/jihad/hl
  export LD_LIBRARY_PATH=/media/internal/jihad/hl JIHAD_DUMP=/media/internal/jihad/frame.ppm JIHAD_BS_NAME=browser JIHAD_OFFSCREEN=1 JIHAD_DISABLE_OMTC=1
  ./ld-2.23.so --library-path /media/internal/jihad/hl ./jihad-browserserver /media/internal/jihad/hl >/media/internal/jihad/integ-d.log 2>&1 & ) &
i=0; while [ $i -lt 30 ]; do grep -q "serving YAP 'browser'" /media/internal/jihad/integ-d.log 2>/dev/null && break; sleep 1; i=$((i+1)); done
c=0; while [ $c -lt 6 ]; do grep -q "client connected" /media/internal/jihad/integ-d.log 2>/dev/null && break; luna-send -n 1 palm://com.palm.applicationManager/launch "$P" >/dev/null 2>&1; sleep 11; c=$((c+1)); done
sleep 3; grep -iE "painted" /media/internal/jihad/integ-d.log | tail -2
