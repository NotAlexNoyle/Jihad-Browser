#!/bin/sh
# Jihad device driver: open/close cards, report pid. Run on device via novacom.
APP=net.riverstonerelay.jihad-browser
LS=/usr/bin/luna-send
jpid(){ $LS -n 1 palm://com.palm.applicationManager/running '{}' 2>/dev/null | \
  sed 's/},/}\n/g' | grep "\"$APP\"" | sed 's/.*"processid": *"\([0-9]*\)".*/\1/' | head -1; }
case "$1" in
  close) P=$(jpid); [ -n "$P" ] && $LS -n 1 palm://com.palm.applicationManager/close "{\"processId\":\"$P\"}" >/dev/null 2>&1; echo "closed=$P";;
  open)  $LS -n 1 palm://com.palm.applicationManager/launch "{\"id\":\"$APP\",\"params\":{\"target\":\"$2\"}}" >/dev/null 2>&1; echo "opened";;
  pid)   echo "pid=$(jpid)";;
esac
