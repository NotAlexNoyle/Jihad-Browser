#!/bin/sh
D=/media/internal/jihad
echo "daemon socket: $(ls /tmp/yapserver.browser 2>/dev/null && echo present || echo ABSENT)"
: > "$D/upstart-daemon.log" 2>/dev/null
P='{"id":"net.riverstonerelay.jihad-browser","params":{"target":"http://example.com"}}'
for t in 1 2 3; do
  grep -q "load done uri=http" "$D/upstart-daemon.log" 2>/dev/null && break
  luna-send -n 1 palm://com.palm.applicationManager/launch "$P" >/dev/null 2>&1
  sleep 12
done
echo "=== example.com lifecycle (state changes + load done) ==="
grep -E 'state top|load done|loaderr|openUrl' "$D/upstart-daemon.log" 2>/dev/null | grep -viE 'data:text|about' | tail -12
