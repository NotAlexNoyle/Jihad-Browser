#!/bin/sh
D=/media/internal/jihad
echo "=== JIHAD_DUMP in the upstart job env? ==="
grep -a 'JIHAD_DUMP' /etc/event.d/jihad 2>/dev/null
echo "=== 'dumped frame' during recent typing? ==="
tail -60 $D/upstart-daemon.log | grep -ac 'dumped frame'
echo "=== frame.ppm mtime (recently written?) ==="
ls -la $D/frame.ppm 2>/dev/null | awk '{print $6,$7,$8}'
