#!/bin/sh
D=/media/internal/jihad
PID0=$(ps -ef|grep '[j]ihad-browserserver'|awk '{print $2}'|head -1)
echo "tap + type + tap-to-move + type. watching daemon $PID0 (60s)..."
i=0; crashed=0
while [ $i -lt 30 ]; do
  sleep 2
  PIDN=$(ps -ef|grep '[j]ihad-browserserver'|awk '{print $2}'|head -1)
  [ -n "$PIDN" ] && [ "$PIDN" != "$PID0" ] && { crashed=1; echo "CRASHED $PID0 -> $PIDN"; break; }
  i=$((i+1))
done
dd if=/dev/fb1 of=$D/fbedit.bgra bs=4096 count=768 2>/dev/null
echo "final daemon: $(ps -ef|grep '[j]ihad-browserserver'|awk '{print $2}'|head -1) crashed=$crashed"
