#!/bin/sh
D=/media/internal/jihad
for p in $(luna-send -n 1 palm://com.palm.applicationManager/running '{}' 2>/dev/null | tr ',' '\n' | grep -oE '"processId":"[0-9]+"' | grep -oE '[0-9]+'); do luna-send -n 1 palm://com.palm.applicationManager/close "{\"processId\":\"$p\"}" 2>/dev/null; done
sleep 2; : > "$D/upstart-daemon.log"
for t in 1 2 3; do
  grep -q "painted.*bytes=[1-9]" "$D/upstart-daemon.log" 2>/dev/null && break
  luna-send -n 1 palm://com.palm.applicationManager/launch "$(cat $D/esmin.json)" >/dev/null 2>&1
  sleep 10
done
echo "painted(nonzero): $(grep -cE 'painted.*bytes=[1-9]' "$D/upstart-daemon.log")"
