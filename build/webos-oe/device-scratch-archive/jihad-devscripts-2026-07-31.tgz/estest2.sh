#!/bin/sh
D=/media/internal/jihad
: > "$D/upstart-daemon.log"
luna-send -n 1 palm://com.palm.applicationManager/launch "$(cat $D/espayload.json)" 2>&1 | tail -1
sleep 10
echo "painted: $(grep -c painted "$D/upstart-daemon.log")"
