#!/bin/sh
D=/media/internal/jihad
luna-send -n 1 palm://com.palm.applicationManager/launch "$(cat $D/espayload.json)" >/dev/null 2>&1
sleep 11
echo "painted: $(grep -c painted "$D/upstart-daemon.log")"
