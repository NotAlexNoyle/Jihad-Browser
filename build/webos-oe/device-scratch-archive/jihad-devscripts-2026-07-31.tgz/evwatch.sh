#!/bin/sh
D=/media/internal/jihad
echo "tap + type now (waiting 45s)..."
sleep 45
echo "=== distinct NPAPI event types the plugin received ==="
grep -a '\[ev\]' $D/adapter.log | sort | uniq -c | sort -rn | head -20
echo "=== daemon editorFocused/insertStr ==="
tail -20 $D/upstart-daemon.log | grep -aE 'editorFocused|insertStr|keyDown' | tail -5
