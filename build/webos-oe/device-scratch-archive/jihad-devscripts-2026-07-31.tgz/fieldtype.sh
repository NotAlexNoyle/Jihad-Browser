#!/bin/sh
echo "=== PalmSystem editorFocused / field type enum in enyo+luna ==="
grep -rnE 'editorFocused|fieldType|PalmSKeyboard|keyboardType|Mojo.*Keyboard|MojoKeyboard' /usr/palm/frameworks/enyo/0.10/framework/source 2>/dev/null | grep -iE 'fieldtype|keyboardtype|editorfocus' | head
echo "=== field type constants (numeric) ==="
grep -rnoE 'FieldType[A-Za-z]* *[:=] *[0-9]+|kFieldType[A-Za-z]*|[A-Za-z]*FieldType *= *[0-9]+' /usr/palm/frameworks/enyo 2>/dev/null | head
echo "=== what the STOCK browser adapter/service passes (BrowserServer sysmgr) ==="
grep -rnoE 'editorFocused[^;]*' /usr/lib/luna/system/luna-applauncher 2>/dev/null | head -2
