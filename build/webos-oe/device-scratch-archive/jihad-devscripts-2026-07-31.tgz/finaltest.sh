#!/bin/sh
D=/media/internal/jihad
PID0=$(ps -ef|grep '[j]ihad-browserserver'|awk '{print $2}'|head -1)
echo "waiting for editorFocused (tap box, then TYPE)..."
i=0; seen=0
while [ $i -lt 24 ]; do
  sleep 4
  tail -20 $D/upstart-daemon.log | grep -a 'editorFocused=1' >/dev/null && seen=1
  [ $seen -eq 1 ] && break
  i=$((i+1))
done
echo "editorFocused=$seen; giving 12s to type..."
sleep 12
dd if=/dev/fb1 of=$D/fbfinal.bgra bs=4096 count=768 2>/dev/null
PID1=$(ps -ef|grep '[j]ihad-browserserver'|awk '{print $2}'|head -1)
echo "daemon $PID0 -> $PID1 $([ "$PID0" = "$PID1" ] && echo STABLE || echo CRASHED)"
echo "=== VKB blit (buffer<dst should now blit, not hold) ==="
grep -a '\[hp\]' $D/adapter.log | grep -E 'rH=602|bufH=602' | tail -2
echo "=== daemon paints after focus ==="; grep -aE 'editorFocused|painted' $D/upstart-daemon.log | tail -5
