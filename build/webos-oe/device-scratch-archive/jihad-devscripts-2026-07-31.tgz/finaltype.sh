#!/bin/sh
D=/media/internal/jihad
PID0=$(ps -ef|grep '[j]ihad-browserserver'|awk '{print $2}'|head -1)
echo "tap + type now..."
i=0; seen=0
while [ $i -lt 22 ]; do sleep 4; tail -20 $D/upstart-daemon.log | grep -a 'editorFocused=1' >/dev/null && seen=1; [ $seen -eq 1 ] && break; i=$((i+1)); done
echo "focused=$seen; 12s to type..."; sleep 12
dd if=/dev/fb1 of=$D/fbfin.bgra bs=4096 count=768 2>/dev/null
PID1=$(ps -ef|grep '[j]ihad-browserserver'|awk '{print $2}'|head -1)
echo "daemon $PID0 -> $PID1 $([ "$PID0" = "$PID1" ] && echo STABLE || echo CRASHED)"
