#!/bin/sh
echo "loadavg: $(cat /proc/loadavg)"
echo "=== top 6 by CPU ==="
ps -ef 2>/dev/null | sort -k4 -rn 2>/dev/null | head -6 | awk '{cmd=""; for(i=8;i<=NF;i++)cmd=cmd" "$i; print $2, $4"%", cmd}'
echo "=== ld-2.23.so daemon procs ==="
ps -ef | grep '[l]d-2.23.so' | awk '{print $2, $3}'
echo "=== D-state (uninterruptible) procs count ==="
ps -eo stat 2>/dev/null | grep -c '^D'
