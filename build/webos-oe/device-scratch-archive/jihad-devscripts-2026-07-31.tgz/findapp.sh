#!/bin/sh
echo "=== find installed jihad app dir (has appinfo.json) ==="
for base in /media/cryptofs/apps/usr/palm/applications /var/palm/jail; do
  find "$base" -maxdepth 3 -name appinfo.json 2>/dev/null | grep -i jihad
done
echo "=== find installed depends.js ==="
find /media/cryptofs/apps -name depends.js 2>/dev/null | grep -i jihad
echo "=== is enyo-1.0 bundled next to the app ==="
find /media/cryptofs/apps -maxdepth 6 -name enyo.js 2>/dev/null | grep -i jihad | head
