#!/bin/sh
P=$(ps -ef | grep '[j]ihad-browserserver' | awk '{print $2}' | head -1)
echo "pid:$P"
tr '\0' ' ' < /proc/$P/cmdline 2>/dev/null; echo
echo "conf:"; ls /etc/event.d/jihad /etc/init/jihad.conf 2>/dev/null
grep -h 'browserserver\|exec' /etc/event.d/jihad /etc/init/jihad.conf 2>/dev/null | head
echo "disk-md5:"; md5sum /media/internal/jihad/jihad-browserserver-arm 2>/dev/null
find /media/internal/jihad /var/usr -name 'jihad-browserserver*' 2>/dev/null | head
