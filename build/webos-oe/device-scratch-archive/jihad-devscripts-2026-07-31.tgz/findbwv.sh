#!/bin/sh
echo "=== BasicWebView.js on device ==="
find /usr/palm /usr/lib/luna -iname 'BasicWebView*' 2>/dev/null | head
echo "=== editorFocused + keyboard/insertString flow in it ==="
F=$(find /usr/palm -iname 'BasicWebView.js' 2>/dev/null | head -1)
[ -n "$F" ] && grep -nE 'editorFocused|insertStringAtCursor|manualKeyboard|keyboardShow|ManualFocus|spellCheck|keyUp|keyDown|PalmSystem' "$F" | head -20
