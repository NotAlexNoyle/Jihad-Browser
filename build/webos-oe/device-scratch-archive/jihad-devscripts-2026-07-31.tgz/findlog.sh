#!/bin/sh
echo "=== log files ==="
ls -la /var/log/ 2>/dev/null
echo "=== messages size ==="
wc -l /var/log/messages 2>/dev/null
