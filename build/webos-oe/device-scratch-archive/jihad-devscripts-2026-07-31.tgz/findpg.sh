#!/bin/sh
find /usr/include /usr/local/include -iname 'PGContext.h' -o -iname 'PGSurface.h' 2>/dev/null | head
echo "libWebKitLuna exports PGSurface/PGContext?"
for l in /usr/lib/libWebKitLuna.so /usr/lib/luna/*.so; do [ -f "$l" ] && { nm -D "$l" 2>/dev/null | grep -iE 'PGSurface|PGContext.*bitblt|wrap' | head -3; break; }; done 2>/dev/null
