#!/bin/sh
echo "=== Piranha headers anywhere on device ==="
find / -iname 'PGContext.h' -o -iname 'PGSurface.h' -o -iname 'PGSharedContext.h' 2>/dev/null | head
echo "=== Piranha include dir ==="
find /usr/include -type d -iname 'Piranha' 2>/dev/null | head; ls /usr/include/Piranha 2>/dev/null | head
echo "=== libWebKitLuna / webkit .so location ==="
find /usr/lib /usr/palm -iname '*WebKit*.so*' 2>/dev/null | head
