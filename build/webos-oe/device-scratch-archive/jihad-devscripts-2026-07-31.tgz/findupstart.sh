#!/bin/sh
for f in /etc/event.d/browserserver /etc/init/browserserver.conf /etc/event.d/BrowserServer /etc/init/BrowserServer.conf; do
  if [ -f "$f" ]; then echo "=== $f ==="; cat "$f"; fi
done
echo "=== search event.d/init for browser ==="
ls /etc/event.d/ 2>/dev/null | grep -i brows
ls /etc/init/ 2>/dev/null | grep -i brows
