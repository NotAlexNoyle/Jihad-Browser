#!/bin/sh
D=/media/internal/jihad
APP=/media/cryptofs/apps/usr/palm/applications/net.riverstonerelay.jihad-browser
echo "src .new: $(md5sum $D/BrowserAdapterImpl.so.new|cut -c1-12) size=$(wc -c <$D/BrowserAdapterImpl.so.new)"
# robust copy via cat (cp hit EBADF on this fs)
cat $D/BrowserAdapterImpl.so.new > $APP/BrowserAdapterImpl.so; sync
cat $D/BrowserAdapterImpl.so.new > $D/BrowserAdapterImpl.so; sync
chmod 755 $APP/BrowserAdapterImpl.so $D/BrowserAdapterImpl.so
echo "app impl:  $(md5sum $APP/BrowserAdapterImpl.so|cut -c1-12) size=$(wc -c <$APP/BrowserAdapterImpl.so)"
echo "dev impl:  $(md5sum $D/BrowserAdapterImpl.so|cut -c1-12) size=$(wc -c <$D/BrowserAdapterImpl.so)"
echo "DEV marker: $([ -f $D/DEV ] && echo yes)"
