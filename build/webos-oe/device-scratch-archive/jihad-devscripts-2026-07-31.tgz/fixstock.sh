#!/bin/sh
mount -o remount,rw / 2>/dev/null
# stop + remove the stray backup job (upstart was running it as the stock BrowserServer)
/sbin/stop browserserver.stock 2>/dev/null
mv /etc/event.d/browserserver.stock /media/internal/jihad/browserserver.stock.bak 2>/dev/null
/usr/bin/pkill -9 -f '/usr/bin/BrowserServer' 2>/dev/null
sleep 2
echo "=== after cleanup ==="
echo "stock BrowserServer running: $(ps -ef | grep -c '[/]usr/bin/BrowserServer ')"
echo "jihad daemon instances: $(ps -ef | grep -c '[l]d-2.23.so')"
echo "socket holder: $(fuser /tmp/yapserver.browser 2>/dev/null)"
echo "jihad serving: $(grep -c "serving YAP 'browser'" /media/internal/jihad/upstart-daemon.log)"
echo "loadavg: $(cat /proc/loadavg)"
echo "event.d browser jobs: $(ls /etc/event.d/ | grep -i brows | tr '\n' ' ')"
