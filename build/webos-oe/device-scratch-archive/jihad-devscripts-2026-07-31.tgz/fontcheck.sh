#!/bin/sh
echo "=== FONTCONFIG_PATH in upstart daemon env ==="
P=$(ps -ef | grep '[j]ihad-browserserver' | awk '{print $2}' | head -1)
[ -n "$P" ] && cat /proc/$P/environ 2>/dev/null | tr '\0' '\n' | grep -iE 'FONTCONFIG|FONT' || echo "(no FONTCONFIG in env)"
echo "=== system fontconfig antialias setting ==="
grep -rl -iE 'antialias' /etc/fonts/ 2>/dev/null | head -3
grep -A1 -iE 'antialias' /etc/fonts/conf.d/*.conf 2>/dev/null | head -8
echo "=== monospace fonts available (bundle + system) ==="
ls /media/internal/jihad/hl/*.ttf /media/internal/jihad/hl/fonts 2>/dev/null | head
ls /usr/share/fonts/ 2>/dev/null | head
find /usr/share/fonts /usr/fonts -iname '*mono*' 2>/dev/null | head
echo "=== goanna.js gfx.font antialias-related ==="
grep -iE 'gfx.content.text_antialiasing|gfx.font_rendering.directwrite|font.antialias|gfx.text' /media/internal/jihad/hl/goanna.js 2>/dev/null | head
