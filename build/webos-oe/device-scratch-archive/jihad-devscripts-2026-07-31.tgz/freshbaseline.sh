#!/bin/sh
D=/media/internal/jihad
: > $D/adapter.log
# verify daemon build
echo "daemon md5: $(md5sum $D/hl/jihad-browserserver | cut -c1-12) (expect 346b1ddf)"
CP=$(luna-send -n 1 palm://com.palm.applicationManager/running '{}' 2>/dev/null | tr '{' '\n' | grep 'jihad-browser' | grep -oE 'processid[^0-9]*[0-9]+' | grep -oE '[0-9]+' | head -1)
[ -n "$CP" ] && luna-send -n 1 palm://com.palm.applicationManager/close "{\"processId\":\"$CP\"}" 2>/dev/null >/dev/null
sleep 4
luna-send -n 1 palm://com.palm.applicationManager/launch '{"id":"net.riverstonerelay.jihad-browser","params":{"target":"data:text/html,<meta name=viewport content=width=device-width><body style=background:%23bbddff;font-size:40px;padding:30px>Tap box, then type:<br><br><input style=font-size:36px;width:85%25;padding:12px;background:white></body>"}}' 2>/dev/null | head -1
sleep 9
dd if=/dev/fb1 of=$D/fbbase.bgra bs=4096 count=768 2>/dev/null
echo "shim reload on card reopen:"; tail -2 $D/shim.log
echo "baseline paint:"; grep -a painted $D/upstart-daemon.log | tail -1
