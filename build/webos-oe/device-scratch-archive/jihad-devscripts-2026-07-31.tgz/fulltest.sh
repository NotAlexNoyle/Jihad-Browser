#!/bin/sh
P='{"id":"net.riverstonerelay.jihad-browser","params":{"target":"data:text/html,<body style=font-size:22px;font-family:sans-serif>UA:<br><script>document.write(navigator.userAgent)</script></body>"}}'
# close any jihad card
for p in $(luna-send -n 1 palm://com.palm.applicationManager/running '{}' 2>/dev/null | tr '}' '\n' | grep 'net.riverstonerelay.jihad-browser' | grep -oE '"processid":"[0-9]+"' | grep -oE '[0-9]+'); do
  luna-send -n 1 palm://com.palm.applicationManager/close "{\"processId\":\"$p\"}" 2>/dev/null; done
sleep 3
/sbin/stop browserserver 2>/dev/null; /usr/bin/pkill -9 -f jihad-browserserver 2>/dev/null; sleep 2; rm -f /tmp/yapserver.browser*
rm -f /media/internal/jihad/integ-d.log /media/internal/jihad/frame.ppm
( cd /media/internal/jihad/hl
  export LD_LIBRARY_PATH=/media/internal/jihad/hl JIHAD_DUMP=/media/internal/jihad/frame.ppm JIHAD_BS_NAME=browser JIHAD_OFFSCREEN=1 JIHAD_DISABLE_OMTC=1
  ./ld-2.23.so --library-path /media/internal/jihad/hl ./jihad-browserserver /media/internal/jihad/hl >/media/internal/jihad/integ-d.log 2>&1 & ) &
i=0; while [ $i -lt 45 ]; do grep -q "serving YAP 'browser'" /media/internal/jihad/integ-d.log 2>/dev/null && break; sleep 1; i=$((i+1)); done
echo "daemon serving after ${i}s"; sleep 2
echo "-- launch #1 --"; luna-send -n 1 palm://com.palm.applicationManager/launch "$P" 2>&1; sleep 9
R1=$(luna-send -n 1 palm://com.palm.applicationManager/running '{}' 2>/dev/null | tr '}' '\n' | grep -c 'net.riverstonerelay.jihad-browser')
echo "running after #1: $R1"
if [ "$R1" -eq 0 ]; then echo "-- launch #2 (fresh-open crash workaround) --"; luna-send -n 1 palm://com.palm.applicationManager/launch "$P" 2>&1; sleep 10; fi
R2=$(luna-send -n 1 palm://com.palm.applicationManager/running '{}' 2>/dev/null | tr '}' '\n' | grep -c 'net.riverstonerelay.jihad-browser')
echo "running now: $R2"
sleep 3
echo "-- dumped-frame count + last paints --"
grep -c "dumped frame" /media/internal/jihad/integ-d.log
grep -E "painted|dumped" /media/internal/jihad/integ-d.log | tail -6
