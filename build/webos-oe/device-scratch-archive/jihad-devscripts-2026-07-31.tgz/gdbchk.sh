which gdb 2>/dev/null || echo "no-gdb"
ulimit -c
cat /proc/sys/kernel/core_pattern 2>/dev/null
