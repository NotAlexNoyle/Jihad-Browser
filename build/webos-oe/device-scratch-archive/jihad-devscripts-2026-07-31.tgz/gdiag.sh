echo "=== UA OVERRIDE HITS ==="
grep -aE "uaoverride" /media/internal/jihad/upstart-daemon.log 2>/dev/null | tail -15
echo "=== RECENT FLOW ==="
grep -aE "clickAt|vkb|editorFocused|google|load done|openUrl|uaoverride|state top f=0xf" /media/internal/jihad/upstart-daemon.log 2>/dev/null | tail -40
