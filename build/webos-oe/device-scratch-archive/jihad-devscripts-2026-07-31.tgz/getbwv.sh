#!/bin/sh
cat /usr/palm/frameworks/enyo/0.10/framework/source/palm/controls/BasicWebView.js 2>/dev/null
