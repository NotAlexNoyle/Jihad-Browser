#!/bin/sh
D=/media/internal/jihad
ls -la $D/frame.ppm 2>/dev/null
head -c 40 $D/frame.ppm 2>/dev/null | tr '\n' '|'; echo
