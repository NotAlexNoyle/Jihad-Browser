grep -nE "surfacecache|frame_rate|sessionhistory|cache.memory|discard|smoothScroll|animation_mode|initialpaint" /media/internal/jihad/hl/goanna.js 2>/dev/null
