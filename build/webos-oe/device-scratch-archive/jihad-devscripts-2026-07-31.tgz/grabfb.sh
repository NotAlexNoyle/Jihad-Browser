#!/bin/sh
D=/media/internal/jihad
dd if=/dev/fb1 of=$D/fbnow.bgra bs=4096 count=768 2>/dev/null
echo "captured:$(wc -c < $D/fbnow.bgra) daemon:$(ps -ef|grep '[j]ihad-browserserver'|awk '{print $2}'|head -1)"
echo "last paints:"; grep -a 'painted' $D/upstart-daemon.log | tail -3
