ls -la /media/internal/jihad/hl/ 2>/dev/null | grep -iE "omni|greprefs|prefs|defaults|\.js" | head
echo "---dirs---"
ls /media/internal/jihad/hl/ 2>/dev/null | head -30
