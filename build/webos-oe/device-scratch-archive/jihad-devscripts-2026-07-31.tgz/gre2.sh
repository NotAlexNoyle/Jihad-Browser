echo "=== defaults tree ==="
ls -R /media/internal/jihad/hl/defaults 2>/dev/null | head -20
echo "=== greprefs.js anywhere ==="
find /media/internal/jihad/hl -name "greprefs.js" 2>/dev/null
echo "=== surfacecache in goanna.js / defaults ==="
grep -rl "surfacecache" /media/internal/jihad/hl/goanna.js /media/internal/jihad/hl/defaults 2>/dev/null
