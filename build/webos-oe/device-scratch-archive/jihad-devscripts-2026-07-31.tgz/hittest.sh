#!/bin/sh
D=/media/internal/jihad
echo "=== hit-test results (from your taps) ==="
grep -a 'clickAt hittest' "$D/upstart-daemon.log" 2>/dev/null | tail -12
echo "=== any navigation after a tap? (link activated) ==="
grep -aiE 'clickAt hittest|state top.*START|load done uri=http' "$D/upstart-daemon.log" 2>/dev/null | tail -12
