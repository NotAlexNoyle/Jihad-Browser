#!/bin/sh
echo "=== instantaneous top CPU (find the hog) ==="
top -bn1 2>/dev/null | sed -n '1,4p;7,16p'
echo "=== fb1 geometry ==="
echo " fb1 virtual_size: $(cat /sys/class/graphics/fb1/virtual_size 2>/dev/null)  stride: $(cat /sys/class/graphics/fb1/stride 2>/dev/null)  bpp: $(cat /sys/class/graphics/fb1/bits_per_pixel 2>/dev/null)"
# capture fb1 (content plane)
dd if=/dev/fb1 of=/media/internal/jihad/fb1.bgra bs=4096 count=768 2>/dev/null
echo " captured fb1: $(wc -c < /media/internal/jihad/fb1.bgra) bytes"
