#!/bin/sh
# hands-off: sample loadavg + daemon cpu over 24s WITHOUT other activity
J=$(ps -ef 2>/dev/null | grep '[j]ihad-browserserver' | awk '{print $2}' | head -1)
for i in 1 2 3 4; do
  A=$(awk '{print $14+$15}' /proc/$J/stat 2>/dev/null)
  sleep 6
  B=$(awk '{print $14+$15}' /proc/$J/stat 2>/dev/null)
  echo "t+$((i*6))s loadavg=$(cut -d' ' -f1 /proc/loadavg) daemonCPU=$(( (B-A)*100/600 ))% (of 1 core over 6s)"
done
echo "jihad daemon alive: $(ps -ef 2>/dev/null | grep -c '[j]ihad-browserserver')  card: $(luna-send -n 1 palm://com.palm.applicationManager/running '{}' 2>/dev/null | grep -c jihad)"
