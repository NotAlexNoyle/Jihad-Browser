#!/bin/sh
D=/media/internal/jihad
echo "=== rootfs rw: install adapter (alongside stock) + jihad upstart job ==="
mount -o remount,rw / 2>/dev/null
cp "$D/BrowserAdapterJihad.so" /usr/lib/BrowserPlugins/BrowserAdapterJihad.so
chmod 755 /usr/lib/BrowserPlugins/BrowserAdapterJihad.so
cp "$D/event.d-jihad" /etc/event.d/jihad
chmod 644 /etc/event.d/jihad
sync
mount -o remount,ro / 2>/dev/null
echo "adapters present:"; ls -la /usr/lib/BrowserPlugins/BrowserAdapter*.so | awk '{print " ",$5,$NF}'
echo "event.d browser jobs:"; ls /etc/event.d/ | grep -iE 'brows|jihad' | tr '\n' ' '; echo

echo "=== make daemon live (.OFF -> jihad-browserserver) ==="
[ -f "$D/hl/jihad-browserserver.OFF" ] && mv "$D/hl/jihad-browserserver.OFF" "$D/hl/jihad-browserserver"
ls -la "$D/hl/jihad-browserserver" 2>/dev/null | awk '{print " daemon",$5,$NF}'

echo "=== start jihad daemon (own job; stock browserserver untouched) ==="
/sbin/start jihad 2>&1 | head -2
sleep 4
echo "=== sockets ==="
echo " stock browser  : $(ls -la /tmp/yapserver.browser 2>/dev/null | awk '{print $NF}' || echo NONE)"
echo " jihad-browser  : $(ls -la /tmp/yapserver.jihad-browser 2>/dev/null | awk '{print $NF}' || echo NONE)"
echo "=== procs ==="
echo " BrowserServer(stock): $(ps -ef 2>/dev/null | grep -c '[/]usr/bin/BrowserServer')"
echo " jihad-browserserver : $(ps -ef 2>/dev/null | grep -c '[j]ihad-browserserver')"
echo "loadavg: $(cut -d' ' -f1-3 /proc/loadavg)"
