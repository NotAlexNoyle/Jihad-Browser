#!/bin/sh
mount -o remount,rw / 2>/dev/null
# stop any current daemon/supervisor first
rm -f /media/internal/jihad/keepalive.on
/usr/bin/pkill -9 -f keepalive.sh 2>/dev/null
/sbin/stop browserserver 2>/dev/null
/usr/bin/pkill -9 -f jihad-browserserver 2>/dev/null
sleep 1
# back up stock job once
[ -f /etc/event.d/browserserver.stock ] || cp /etc/event.d/browserserver /etc/event.d/browserserver.stock
cp /media/internal/jihad/browserserver.jihad /etc/event.d/browserserver
echo "installed jihad upstart job:"; grep -c jihad-browserserver /etc/event.d/browserserver
