#!/bin/sh
D=/media/internal/jihad
PLG=/usr/lib/BrowserPlugins/BrowserAdapterJihad.so
mount -o remount,rw / 2>/dev/null
# backup current registered plugin once
[ -f "$PLG.prejihadshim" ] || cp "$PLG" "$PLG.prejihadshim" 2>/dev/null
cp "$D/BrowserAdapterJihad.so.shim" "$PLG"
chmod 755 "$PLG"
chmod 755 "$D/BrowserAdapterImpl.so"
# also drop the impl into the app bundle if that dir exists (true self-contained)
APP=/media/cryptofs/apps/usr/palm/applications/net.riverstonerelay.jihad-browser
[ -d "$APP" ] && { cp "$D/BrowserAdapterImpl.so" "$APP/BrowserAdapterImpl.so"; chmod 755 "$APP/BrowserAdapterImpl.so"; echo "impl -> app bundle: yes"; } || echo "app bundle dir: MISSING"
sync
echo "=== installed ==="
echo "shim  @ $PLG:"; md5sum "$PLG"
echo "impl  @ jihad dir:"; md5sum "$D/BrowserAdapterImpl.so"
[ -d "$APP" ] && { echo "impl  @ app bundle:"; md5sum "$APP/BrowserAdapterImpl.so"; }
echo "shim size (should be ~5908):"; ls -la "$PLG" | awk '{print $5}'
