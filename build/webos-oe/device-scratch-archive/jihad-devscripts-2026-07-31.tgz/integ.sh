#!/bin/sh
# Full device UI integration: our isis-generation BrowserAdapter + Jihad Goanna daemon.
BP=/usr/lib/BrowserPlugins
echo "== remount rootfs rw =="
mount -o remount,rw / 2>&1
echo "== back up stock adapter + install ours =="
[ -f "$BP/BrowserAdapter.so.stock" ] || cp "$BP/BrowserAdapter.so" "$BP/BrowserAdapter.so.stock"
cp /media/internal/jihad/BrowserAdapter.so "$BP/BrowserAdapter.so"
chmod 755 "$BP/BrowserAdapter.so"
ls -la "$BP/BrowserAdapter.so" | awk '{print "  installed:",$5}'
echo "== stop stock BrowserServer, start Jihad daemon as 'browser' =="
/sbin/stop browserserver 2>&1 | tail -1
/usr/bin/pkill -9 -f '/usr/bin/BrowserServer -d' 2>/dev/null
sleep 1
cd /media/internal/jihad/hl
chmod 755 ld-2.23.so jihad-browserserver 2>/dev/null
export JIHAD_OFFSCREEN=1 JIHAD_DISABLE_OMTC=1 FONTCONFIG_PATH=/etc/fonts JIHAD_BS_NAME=browser
rm -f /media/internal/jihad/integ-d.log
( ./ld-2.23.so --library-path /media/internal/jihad/hl ./jihad-browserserver /media/internal/jihad/hl >/media/internal/jihad/integ-d.log 2>&1 & ) &
i=0; while [ $i -lt 30 ]; do grep -q "serving YAP 'browser'" /media/internal/jihad/integ-d.log 2>/dev/null && break; sleep 1; i=$((i+1)); done
echo "  daemon up in ${i}s: $(grep -c 'serving YAP' /media/internal/jihad/integ-d.log)"
echo "== close any existing Jihad card, then launch fresh =="
/usr/bin/luna-send -n 1 palm://com.palm.applicationManager/close '{"id":"net.riverstonerelay.jihad"}' 2>/dev/null; sleep 2
/usr/bin/luna-send -n 1 palm://com.palm.applicationManager/launch '{"id":"net.riverstonerelay.jihad","params":{"target":"http://example.com/"}}' 2>&1
sleep 20
echo "== daemon log (should parse the REAL adapter's commands now) =="
grep -vE 'Fontconfig warning' /media/internal/jihad/integ-d.log 2>/dev/null | tail -25
