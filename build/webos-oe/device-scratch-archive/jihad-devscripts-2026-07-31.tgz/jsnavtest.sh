#!/bin/sh
D=/media/internal/jihad
CP=$(luna-send -n 1 palm://com.palm.applicationManager/running '{}' 2>/dev/null | sed 's/},{/}\n{/g' | grep -i jihad | grep -oiE 'processid[": ]+[0-9]+' | grep -oE '[0-9]+' | head -1)
[ -n "$CP" ] && luna-send -n 1 palm://com.palm.applicationManager/close "{\"processId\":\"$CP\"}" 2>/dev/null >/dev/null
sleep 2
DLOG=$(wc -l < "$D/upstart-daemon.log" 2>/dev/null || echo 0)
echo "=== load a page whose JS does location.href='http://example.net' after 1.5s ==="
luna-send -n 1 palm://com.palm.applicationManager/launch '{"id":"net.riverstonerelay.jihad-browser","params":{"target":"data:text/html,<body>JS-NAV-TEST<script>setTimeout(function(){location.href=String.fromCharCode(104)+String.fromCharCode(116)+String.fromCharCode(116)+String.fromCharCode(112)+String.fromCharCode(58)+String.fromCharCode(47)+String.fromCharCode(47)+String.fromCharCode(101)+String.fromCharCode(120)+String.fromCharCode(97)+String.fromCharCode(109)+String.fromCharCode(112)+String.fromCharCode(108)+String.fromCharCode(101)+String.fromCharCode(46)+String.fromCharCode(110)+String.fromCharCode(101)+String.fromCharCode(116)+String.fromCharCode(47)},1500)</script></body>"}}' 2>&1 | head -1
sleep 10
echo "=== did JS nav to example.net complete? ==="
tail -n +$((DLOG+1)) "$D/upstart-daemon.log" 2>/dev/null | grep -aiE 'openUrl|load done uri=|loaderr|state top.*START' | tail -10
echo "final URL: $(grep -a 'load done uri=' $D/upstart-daemon.log 2>/dev/null | tail -1 | cut -c1-50)"
