#!/bin/sh
D=/media/internal/jihad
echo "uptime:$(cut -d. -f1 /proc/uptime)s daemon:$(ps -ef 2>/dev/null|grep -c '[j]ihad-browserserver') md5:$(md5sum $D/hl/jihad-browserserver 2>/dev/null|cut -d' ' -f1) respawns-since-boot:$(grep -c 'engine up' $D/upstart-daemon.log 2>/dev/null)"
CP=$(luna-send -n 1 palm://com.palm.applicationManager/running '{}' 2>/dev/null | sed 's/},{/}\n{/g' | grep -i jihad | grep -oiE 'processid[": ]+[0-9]+' | grep -oE '[0-9]+' | head -1)
[ -n "$CP" ] && luna-send -n 1 palm://com.palm.applicationManager/close "{\"processId\":\"$CP\"}" 2>/dev/null >/dev/null
sleep 2
luna-send -n 1 palm://com.palm.applicationManager/launch '{"id":"net.riverstonerelay.jihad-browser","params":{"target":"data:text/html,<body style=font-size:38px><input placeholder=tap-here style=font-size:38px;width:90%25></body>"}}' 2>&1 | head -1
sleep 8
echo "loaded:$(grep -a 'load done uri=' $D/upstart-daemon.log 2>/dev/null|tail -1|cut -c1-35) load:$(cut -d' ' -f1 /proc/loadavg) daemon-pid:$(ps -ef|grep '[j]ihad-browserserver'|awk '{print $2}'|head -1)"
