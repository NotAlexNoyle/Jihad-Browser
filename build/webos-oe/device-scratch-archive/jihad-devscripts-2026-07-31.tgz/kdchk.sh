#!/bin/sh
D=/media/internal/jihad
echo "=== daemon: InsertText / insertStr / editorFocused during typing ==="
tail -30 $D/upstart-daemon.log | grep -aE 'InsertText|insertStr|editorFocused|SKIP' | tail -12
echo "=== adapter: keyDown events (type=8) since last ==="
grep -ac '\[ev\] type=8' $D/adapter.log
