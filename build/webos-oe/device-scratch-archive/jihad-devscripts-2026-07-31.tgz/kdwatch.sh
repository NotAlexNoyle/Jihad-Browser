#!/bin/sh
D=/media/internal/jihad
MARK=$(wc -l < $D/upstart-daemon.log)
echo "tap + type now (45s)..."
sleep 45
echo "=== keyDown diagnostic + InsertText ==="
tail -n +$((MARK+1)) $D/upstart-daemon.log | grep -aE 'keyDown|InsertText|editorFocused' | head -20
