#!/bin/sh
# Persistent supervisor for the Jihad Goanna daemon. Ignores HUP so it survives the
# novacom session closing; respawns the daemon whenever it exits (crash or a deploy
# that kills it to load a new binary). Stop cleanly: rm /media/internal/jihad/keepalive.on
trap '' HUP INT TERM
D=/media/internal/jihad
touch "$D/keepalive.on"
while [ -f "$D/keepalive.on" ]; do
  rm -f /tmp/yapserver.browser*
  cd "$D/hl" || { sleep 2; continue; }
  ( export LD_LIBRARY_PATH="$D/hl" JIHAD_DUMP="$D/frame.ppm" JIHAD_BS_NAME=browser JIHAD_OFFSCREEN=1 JIHAD_DISABLE_OMTC=1
    exec ./ld-2.23.so --library-path "$D/hl" ./jihad-browserserver "$D/hl" ) >>"$D/integ-d.log" 2>&1
  echo "[keepalive] daemon exited, respawning in 1s" >>"$D/integ-d.log"
  sleep 1
done
