#!/bin/sh
# Keep the TouchPad screen on for testing. Hold a display "on+block" SUBSCRIPTION in the
# background (kept alive by this long-running script so its Luna connection never closes),
# plus a periodic power activity (prevents suspend) and a display-on poke.
LS=/usr/bin/luna-send
hold_block() { $LS -i palm://com.palm.display/control/setState '{"state":"on","block":true,"subscribe":true}' >/dev/null 2>&1 & echo $!; }
BLK=$(hold_block)
while true; do
  $LS -n 1 palm://com.palm.power/activityStart '{"id":"jihad-keepawake","duration_ms":120000}' >/dev/null 2>&1
  $LS -n 1 palm://com.palm.display/control/setProperty '{"blockDisplay":true}' >/dev/null 2>&1
  $LS -n 1 palm://com.palm.display/control/setState '{"state":"on"}' >/dev/null 2>&1
  kill -0 "$BLK" 2>/dev/null || BLK=$(hold_block)
  sleep 25
done
