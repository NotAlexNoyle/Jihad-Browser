#!/bin/sh
echo "=== close jihad card processId 1009 ==="
luna-send -n 1 palm://com.palm.applicationManager/close '{"processId":"1009"}' 2>/dev/null | head -1
sleep 4
echo "=== after close ==="
echo " jihad card: $(luna-send -n 1 palm://com.palm.applicationManager/running '{}' 2>/dev/null | grep -c jihad)"
echo " WebAppMgr cpu: $(ps -eo pcpu,comm 2>/dev/null | grep WebAppMgr | awk '{print $1}' | head -1)%"
echo " loadavg: $(cut -d' ' -f1-3 /proc/loadavg)"
echo " jihad daemon: $(ps -ef 2>/dev/null | grep -c '[j]ihad-browserserver')  stock BS: $(ps -ef 2>/dev/null | grep -c '[/]usr/bin/BrowserServer')"
