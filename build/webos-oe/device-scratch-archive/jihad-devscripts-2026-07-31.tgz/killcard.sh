#!/bin/sh
echo "=== running apps (find jihad processId) ==="
luna-send -n 1 palm://com.palm.applicationManager/running '{}' 2>/dev/null > /tmp/running.json
cat /tmp/running.json | tr ',' '\n' | grep -iE 'jihad|processId' | head -20
# extract processId(s) belonging to jihad: crude — grab processId near the jihad id
PID=$(cat /tmp/running.json | sed 's/},{/}\n{/g' | grep -i jihad | grep -oE '"processId":"?[0-9]+' | grep -oE '[0-9]+' | head -1)
echo "jihad processId: ${PID:-none}"
if [ -n "$PID" ]; then
  echo "=== close by processId ==="
  luna-send -n 1 palm://com.palm.applicationManager/close "{\"processId\":\"$PID\"}" 2>/dev/null | head -1
fi
sleep 3
echo "=== after ==="
echo " jihad card: $(luna-send -n 1 palm://com.palm.applicationManager/running '{}' 2>/dev/null | grep -c jihad)"
ps -eo pid,pcpu,comm 2>/dev/null | sort -k2 -rn | head -4
echo " loadavg: $(cut -d' ' -f1-3 /proc/loadavg)"
