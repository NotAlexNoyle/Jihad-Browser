#!/bin/sh
# aggressive: close via appmgr repeatedly, then kill leftover card processes
for round in 1 2 3 4 5 6; do
  PIDS=$(luna-send -n 1 palm://com.palm.applicationManager/running '{}' 2>/dev/null | tr '}' '\n' | grep 'net.riverstonerelay.jihad-browser' | grep -oE '"processid":"[0-9]+"' | grep -oE '[0-9]+')
  [ -z "$PIDS" ] && break
  for p in $PIDS; do luna-send -n 1 palm://com.palm.applicationManager/close "{\"processId\":\"$p\"}" 2>/dev/null; done
  sleep 2
done
echo "after appmgr close: $(luna-send -n 1 palm://com.palm.applicationManager/running '{}' 2>/dev/null | tr '}' '\n' | grep -c 'net.riverstonerelay.jihad-browser')"
