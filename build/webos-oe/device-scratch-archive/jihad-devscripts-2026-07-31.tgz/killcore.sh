#!/bin/sh
# 1) disable the minicore2 pipe so future crashes are cheap (plain small core, or none)
echo core > /proc/sys/kernel/core_pattern 2>/dev/null
ulimit -c 0 2>/dev/null
# 2) kill minicore2 (frees the daemon from D-state I/O)
/usr/bin/pkill -9 minicore2 2>/dev/null
sleep 2
# 3) stop respawn + kill the daemon (now killable)
/sbin/stop browserserver 2>/dev/null
rm -f /media/internal/jihad/keepalive.on
/usr/bin/pkill -9 -f keepalive.sh 2>/dev/null
/usr/bin/pkill -9 -f jihad-browserserver 2>/dev/null
sleep 3
echo "loadavg: $(cat /proc/loadavg | cut -d' ' -f1-3)"
echo "daemon: $(ps -ef | grep -c '[l]d-2.23.so')  minicore2: $(ps -ef | grep -c '[m]inicore2')"
echo "core_pattern: $(cat /proc/sys/kernel/core_pattern)"
