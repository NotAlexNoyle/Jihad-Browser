#!/bin/sh
D=/media/internal/jihad
echo "=== recent clickAt + nav ==="
grep -aiE 'clickAt \(|load done uri=http://example.net|openUrl http://example.net' "$D/upstart-daemon.log" 2>/dev/null | tail -8
echo "=== final URL ==="; grep -a 'load done uri=' "$D/upstart-daemon.log" 2>/dev/null | tail -1 | cut -c1-70
echo "=== jihad card + daemon alive ==="
echo " cards: $(luna-send -n 1 palm://com.palm.applicationManager/running '{}' 2>/dev/null | grep -c jihad)  daemon: $(ps -ef|grep -c '[j]ihad-browserserver')  load: $(cut -d' ' -f1 /proc/loadavg)"
