#!/bin/sh
D=/media/internal/jihad
MARK=$(wc -l < $D/upstart-daemon.log)
echo "type ~10 chars now (40s)..."
sleep 40
echo "=== keyDown total + render times (ms) ==="
tail -n +$((MARK+1)) $D/upstart-daemon.log | grep -aoE 'keyDown total=[0-9]+ms|render=[0-9]+ms' | tail -30
echo "=== count ==="
echo "keyDowns: $(tail -n +$((MARK+1)) $D/upstart-daemon.log | grep -ac 'keyDown total')  paints: $(tail -n +$((MARK+1)) $D/upstart-daemon.log | grep -ac 'painted')"
