#!/bin/sh
PIDS=$(/usr/bin/luna-send -n 1 palm://com.palm.applicationManager/running '{}' 2>/dev/null | tr '{},' '\n\n\n' | grep -A2 'net.riverstonerelay.jihad-browser' | grep -oE '"processId":"[0-9]+"' | grep -oE '[0-9]+')
for p in $PIDS; do /usr/bin/luna-send -n 1 palm://com.palm.applicationManager/close "{\"processId\":\"$p\"}" 2>/dev/null; done
sleep 3
/usr/bin/luna-send -n 1 palm://com.palm.applicationManager/launch '{"id":"net.riverstonerelay.jihad-browser","params":{"target":"https://duckduckgo.com/html/"}}'
