#!/bin/sh
/usr/bin/luna-send -n 1 palm://com.palm.applicationManager/launch '{"id":"net.riverstonerelay.jihad-browser","params":{"target":"data:text/html,<h1>JIHAD BROWSER WORKS</h1><p>Goanna rendering on the TouchPad 12345</p>"}}'
