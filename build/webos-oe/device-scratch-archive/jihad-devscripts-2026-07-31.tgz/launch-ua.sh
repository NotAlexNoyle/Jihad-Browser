#!/bin/sh
# data: URL with NO double-quotes anywhere (document.write + unquoted attr) so the
# luna-send JSON payload stays well-formed.
P='{"id":"net.riverstonerelay.jihad-browser","params":{"target":"data:text/html,<body style=font-size:22px;font-family:sans-serif>UA:<br><script>document.write(navigator.userAgent)</script></body>"}}'
echo "-- launch #1 --"; /usr/bin/luna-send -n 1 palm://com.palm.applicationManager/launch "$P" 2>&1; sleep 9
R1=$(luna-send -n 1 palm://com.palm.applicationManager/running '{}' 2>/dev/null | tr '}' '\n' | grep -c 'net.riverstonerelay.jihad-browser')
echo "-- running after #1: $R1 --"
echo "-- launch #2 --"; /usr/bin/luna-send -n 1 palm://com.palm.applicationManager/launch "$P" 2>&1; sleep 11
R2=$(luna-send -n 1 palm://com.palm.applicationManager/running '{}' 2>/dev/null | tr '}' '\n' | grep -c 'net.riverstonerelay.jihad-browser')
echo "-- running after #2: $R2 --"
