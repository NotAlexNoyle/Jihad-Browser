#!/bin/sh
echo "== launching Jihad UI with target http://example.com/ =="
/usr/bin/luna-send -n 1 palm://com.palm.applicationManager/launch '{"id":"net.riverstonerelay.jihad","params":{"target":"http://example.com/"}}' 2>&1
sleep 18
echo "== daemon log: did the REAL BrowserAdapter connect + drive Jihad? =="
grep -vE 'Fontconfig warning' /media/internal/jihad/browser-d.log 2>/dev/null | tail -25
