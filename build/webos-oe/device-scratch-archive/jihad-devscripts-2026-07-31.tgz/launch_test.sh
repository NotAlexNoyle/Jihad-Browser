#!/bin/sh
D=/media/internal/jihad
sleep 22
: > $D/adapter.log
luna-send -n 1 palm://com.palm.applicationManager/launch '{"id":"net.riverstonerelay.jihad-browser","params":{"target":"data:text/html,<meta name=viewport content=width=device-width><body style=background:%23bbddff;font-size:40px;padding:30px>Tap box, then type:<br><br><input style=font-size:36px;width:85%25;padding:12px;background:white></body>"}}' 2>/dev/null | head -1
sleep 9
echo "=== initial [hp] (adapter loaded, page painted) ==="; grep -a '\[hp\]' $D/adapter.log | tail -2
echo "adapter md5 mapped:"; md5sum $D/BrowserAdapterJihad.so | cut -c1-12
