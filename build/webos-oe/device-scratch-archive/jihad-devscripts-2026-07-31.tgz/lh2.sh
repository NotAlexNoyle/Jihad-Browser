#!/bin/sh
/usr/bin/luna-send -n 1 palm://com.palm.applicationManager/launch '{"id":"net.riverstonerelay.jihad-browser","params":{"target":"https://duckduckgo.com/html/"}}'
