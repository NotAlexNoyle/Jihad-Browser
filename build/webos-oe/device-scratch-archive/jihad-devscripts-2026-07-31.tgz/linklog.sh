grep -aE "clickAt|navigate|LinkClicked|openUrl|iana|https|certErr|load done|loaderr|scheme|fixup" /media/internal/jihad/upstart-daemon.log 2>/dev/null | tail -35
