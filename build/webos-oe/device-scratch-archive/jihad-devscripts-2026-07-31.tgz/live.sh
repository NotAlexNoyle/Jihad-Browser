#!/bin/sh
D=/media/internal/jihad
echo "=== full daemon log ==="; cat "$D/upstart-daemon.log" 2>/dev/null | tail -20
echo "=== adapter.log ==="; cat "$D/adapter.log" 2>/dev/null | tail -15; echo "(bytes: $(wc -c < $D/adapter.log 2>/dev/null))"
echo "=== is an adapter connected to the jihad daemon socket? (daemon FDs) ==="
JPID=$(ps -ef 2>/dev/null | grep '[j]ihad-browserserver' | awk '{print $2}' | head -1)
echo " daemon pid=$JPID; socket/unix FDs:"
ls -l /proc/$JPID/fd 2>/dev/null | grep -iE 'socket|yap' | wc -l | sed 's/^/  fd sockets: /'
echo "=== adapter stderr in syslog (plugin fprintf) — clickAt/emitGeometry/connect ==="
grep -aiE 'jihad-bs|yapserver.jihad|BrowserClientBase|connect.*jihad|yap.*connect' /var/log/messages 2>/dev/null | tail -10
echo "=== jihad card running? ==="
luna-send -n 1 palm://com.palm.applicationManager/running '{}' 2>/dev/null | grep -c jihad | sed 's/^/ jihad cards: /'
echo "=== loadavg: $(cut -d' ' -f1-3 /proc/loadavg) ==="
