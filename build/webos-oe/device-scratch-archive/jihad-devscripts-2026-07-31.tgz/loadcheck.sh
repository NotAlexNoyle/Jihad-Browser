#!/bin/sh
L=/media/internal/jihad/upstart-daemon.log
echo "=== context around whatismybrowser openUrl (full sequence) ==="
grep -nE 'openUrl|load done|loaderr|LoadUrl|NSS|EnsureNSS|jihad_init' "$L" 2>/dev/null | grep -viE 'data:text|about' | tail -20
