#!/bin/sh
L=/media/internal/jihad/upstart-daemon.log
echo "=== NSS flood gone? (count of forwarded-to-main) ==="
grep -c 'forwarded-to-main' "$L" 2>/dev/null
echo "=== whatismybrowser load lifecycle ==="
grep -nE 'openUrl|load done|loaderr|msgLoadStarted|LoadStarted|LoadStopped|progress' "$L" 2>/dev/null | grep -viE 'data:text|about:' | tail -15
echo "=== last 12 log lines (current state) ==="
grep -viE 'Fontconfig' "$L" 2>/dev/null | tail -12 | cut -c1-90
