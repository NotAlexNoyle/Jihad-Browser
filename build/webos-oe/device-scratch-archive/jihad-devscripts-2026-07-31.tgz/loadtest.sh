#!/bin/sh
D=/media/internal/jihad
# close existing jihad card(s)
CP=$(luna-send -n 1 palm://com.palm.applicationManager/running '{}' 2>/dev/null | sed 's/},{/}\n{/g' | grep -i jihad | grep -oiE 'processid[": ]+[0-9]+' | grep -oE '[0-9]+' | head -1)
[ -n "$CP" ] && luna-send -n 1 palm://com.palm.applicationManager/close "{\"processId\":\"$CP\"}" 2>/dev/null >/dev/null
sleep 3
: > "$D/adapter.log"
DLOG=$(wc -l < "$D/upstart-daemon.log" 2>/dev/null || echo 0)
echo "=== launch with target=http://example.com ==="
luna-send -n 1 palm://com.palm.applicationManager/launch '{"id":"net.riverstonerelay.jihad-browser","params":{"target":"http://example.com"}}' 2>&1 | head -1
sleep 10
echo "=== daemon log (this load) ==="
tail -n +$((DLOG+1)) "$D/upstart-daemon.log" 2>/dev/null | grep -aiE 'openUrl|load done|loaderr|contentSize|painted' | tail -12
echo "=== capture fb1 ==="
dd if=/dev/fb1 of="$D/fb1.bgra" bs=4096 count=768 2>/dev/null
echo " fb1 bytes: $(wc -c < $D/fb1.bgra)"
echo "=== health: top idle + WebAppMgr ==="
top -bn1 2>/dev/null | sed -n '3p'
echo " loadavg: $(cut -d' ' -f1-3 /proc/loadavg)"
