grep -aE "clickAt|vkb|state top|load done|openUrl|scrollTo|LinkClicked|editorFocused" /media/internal/jihad/upstart-daemon.log 2>/dev/null | tail -35
