#!/bin/sh
restart LunaSysMgr 2>/dev/null || (stop LunaSysMgr; sleep 1; start LunaSysMgr)
echo "LunaSysMgr restart issued"
