#!/bin/sh
/usr/bin/luna-send -n 1 palm://com.palm.applicationManager/launch '{"id":"net.riverstonerelay.jihad-browser","params":{"target":"data:text/html,<body style=\"font-size:22px;font-family:sans-serif\">Your user agent:<br><b id=x></b><script>document.getElementById(\"x\").textContent=navigator.userAgent</script></body>"}}'
