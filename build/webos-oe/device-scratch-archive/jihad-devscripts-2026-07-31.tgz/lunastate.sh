#!/bin/sh
echo "LunaSysMgr pids: [$(pidof LunaSysMgr)]"
echo "luna respawn count (recent): $(grep -c 'LunaSysMgr' /var/log/messages 2>/dev/null | tail -1)"
echo "which .so mapped by luna:"
for p in /proc/[0-9]*; do
  if grep -q 'BrowserAdapterJihad' "$p/maps" 2>/dev/null; then
    echo "  pid=$(basename $p) cmd=$(tr '\0' ' ' < $p/cmdline|cut -c1-40)"
    grep -oE '/media[^ ]*BrowserAdapterJihad\.so' "$p/maps" | sort -u
  fi
done
echo "jihad cards running:"; luna-send -n 1 palm://com.palm.applicationManager/running '{}' 2>/dev/null | tr '{' '\n' | grep -c jihad-browser
echo "load:$(cut -d' ' -f1-3 /proc/loadavg)"
echo "adapter.log last 3 lines:"; tail -3 /media/internal/jihad/adapter.log
