#!/bin/sh
D=/media/internal/jihad
DLOG=$(wc -l < "$D/upstart-daemon.log" 2>/dev/null || echo 0)
echo "=== launch ==="
luna-send -n 1 palm://com.palm.applicationManager/launch '{"id":"net.riverstonerelay.jihad-browser"}' 2>&1 | head -1
sleep 8
echo "=== which processes loaded a BrowserAdapter .so? (decisive) ==="
for p in /proc/[0-9]*/maps; do
  if grep -qa 'BrowserAdapter' "$p" 2>/dev/null; then
    pid=$(echo "$p" | sed 's#/proc/##;s#/maps##')
    nm=$(cat /proc/$pid/cmdline 2>/dev/null | tr '\0' ' ' | cut -c1-40)
    so=$(grep -a 'BrowserAdapter' "$p" 2>/dev/null | grep -oiE 'BrowserAdapter[A-Za-z]*\.so' | sort -u | tr '\n' ' ')
    echo " pid=$pid [$nm] -> $so"
  fi
done
echo "=== daemon log new lines (adapter connect?) ==="
tail -n +$((DLOG+1)) "$D/upstart-daemon.log" 2>/dev/null | tail -8
echo "=== loadavg: $(cut -d' ' -f1-3 /proc/loadavg) ==="
