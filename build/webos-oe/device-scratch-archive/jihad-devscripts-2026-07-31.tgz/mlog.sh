#!/bin/sh
N=$(wc -l < /var/log/messages)
echo "START_LINE=$N"
