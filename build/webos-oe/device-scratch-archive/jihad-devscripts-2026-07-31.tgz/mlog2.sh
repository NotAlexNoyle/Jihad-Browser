#!/bin/sh
tail -n +990 /var/log/messages | grep -iE "jihad-browser.mochi|mochi|JavaScript|SyntaxError|TypeError|ReferenceError|is not defined|Uncaught|enyo|PmLog.*rror|WebApp|stageReady|Failed" | tail -30
