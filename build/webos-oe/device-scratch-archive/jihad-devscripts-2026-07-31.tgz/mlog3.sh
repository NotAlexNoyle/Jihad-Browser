#!/bin/sh
tail -n +3366 /var/log/messages | grep -iE "mochi.*(Uncaught|stageReady|ReferenceError)|servicecallback_launch.*mochi" | tail -6
