#!/bin/sh
tail -n +11171 /var/log/messages | grep -iE "mochi.*(Uncaught|Error|Exception|undefined|not a function|not defined)" | tail -12
