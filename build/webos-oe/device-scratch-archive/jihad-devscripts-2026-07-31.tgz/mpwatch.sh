#!/bin/sh
D=/media/internal/jihad
MARK=$(wc -l < $D/upstart-daemon.log)
echo "type ~10 chars now (40s)..."
sleep 40
echo "=== per-keystroke breakdown ==="
tail -n +$((MARK+1)) $D/upstart-daemon.log | grep -aoE 'insert=[0-9]+ms paint=[0-9]+ms|render=[0-9]+ms|msgPainted=[0-9]+ms' | tail -24
