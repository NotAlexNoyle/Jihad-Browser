#!/bin/sh
D=/media/internal/jihad
echo "=== full daemon log tail (30) — see what the link click navigates to ==="
tail -30 "$D/upstart-daemon.log" 2>/dev/null
