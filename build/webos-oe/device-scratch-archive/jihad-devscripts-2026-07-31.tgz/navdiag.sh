#!/bin/sh
D=/media/internal/jihad
echo "=== full daemon log tail (35) around the example.net nav ==="
tail -35 "$D/upstart-daemon.log" 2>/dev/null | grep -aiE 'clickAt|openUrl|load done|loaderr|state top|LoadUrl|painted bytes'
echo "=== can the device even reach example.net right now? ==="
timeout 8 curl -sI http://example.net/ 2>&1 | head -3 || echo "(curl failed/absent)"
