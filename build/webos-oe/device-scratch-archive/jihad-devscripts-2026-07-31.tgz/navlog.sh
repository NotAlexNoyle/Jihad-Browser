tail -45 /media/internal/jihad/upstart-daemon.log 2>/dev/null
