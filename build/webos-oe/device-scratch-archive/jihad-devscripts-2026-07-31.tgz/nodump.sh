#!/bin/sh
D=/media/internal/jihad
mount -o remount,rw / 2>/dev/null
# remove the JIHAD_DUMP env line from the upstart job (disables the per-paint 2.2MB PPM write)
sed -i '/JIHAD_DUMP=/d' /etc/event.d/jihad
sync
echo "=== JIHAD_DUMP still present? ==="; grep -c 'JIHAD_DUMP' /etc/event.d/jihad
/sbin/stop jihad 2>/dev/null; sleep 2; /sbin/start jihad 2>/dev/null; sleep 4
CP=$(luna-send -n 1 palm://com.palm.applicationManager/running '{}' 2>/dev/null | tr '{' '\n' | grep 'jihad-browser' | grep -oE 'processid[^0-9]*[0-9]+' | grep -oE '[0-9]+' | head -1)
[ -n "$CP" ] && luna-send -n 1 palm://com.palm.applicationManager/close "{\"processId\":\"$CP\"}" 2>/dev/null >/dev/null
sleep 3
luna-send -n 1 palm://com.palm.applicationManager/launch '{"id":"net.riverstonerelay.jihad-browser","params":{"target":"data:text/html,<meta name=viewport content=width=device-width><body style=background:%23bbddff;font-size:40px;padding:30px>Tap box, then type:<br><br><input style=font-size:36px;width:85%25;padding:12px;background:white></body>"}}' 2>/dev/null | head -1
sleep 8
echo "ready. daemon: $(ps -ef|grep '[j]ihad-browserserver'|awk '{print $2}'|head -1)"
