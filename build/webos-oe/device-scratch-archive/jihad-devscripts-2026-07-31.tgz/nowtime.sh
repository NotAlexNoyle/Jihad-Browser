#!/bin/sh
D=/media/internal/jihad
echo "=== recent per-keystroke timings ==="
tail -40 $D/upstart-daemon.log | grep -aoE 'insert=[0-9]+ms paint=[0-9]+ms|render=[0-9]+ms' | tail -20
