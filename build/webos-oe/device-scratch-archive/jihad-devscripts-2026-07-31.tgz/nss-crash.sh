#!/bin/sh
cd /media/internal/jihad
ulimit -c unlimited
rm -f core core.* /media/internal/jihad/nss-d.log
cd /media/internal/jihad/hl
export JIHAD_OFFSCREEN=1 JIHAD_DISABLE_OMTC=1 FONTCONFIG_PATH=/etc/fonts
export JIHAD_URL='https://duckduckgo.com/html/'
export JIHAD_BS_NAME=jihad-browserserver
# core dumps land in CWD (hl/) — make sure kernel writes plain "core"
echo core > /proc/sys/kernel/core_pattern 2>/dev/null
( ./ld-2.23.so --library-path /media/internal/jihad/hl ./jihad-browserserver /media/internal/jihad/hl >/media/internal/jihad/nss-d.log 2>&1 & )
sleep 16
( ./ld-2.23.so --library-path /media/internal/jihad/hl ./jihad-adapter-arm >/media/internal/jihad/nss-a.log 2>&1 & )
sleep 12
/usr/bin/pkill -9 jihad-adapter 2>/dev/null; /usr/bin/pkill -9 jihad-browser 2>/dev/null
echo "=== core files ==="; ls -la /media/internal/jihad/hl/core* /media/internal/jihad/core* 2>/dev/null
