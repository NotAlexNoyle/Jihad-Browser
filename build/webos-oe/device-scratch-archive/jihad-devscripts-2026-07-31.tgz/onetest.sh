#!/bin/sh
P='{"id":"net.riverstonerelay.jihad-browser","params":{"target":"about:jihad"}}'
# close any existing card first
for p in $(luna-send -n 1 palm://com.palm.applicationManager/running '{}' 2>/dev/null | tr '}' '\n' | grep 'net.riverstonerelay.jihad-browser' | grep -oE '"processid":"[0-9]+"' | grep -oE '[0-9]+'); do luna-send -n 1 palm://com.palm.applicationManager/close "{\"processId\":\"$p\"}" 2>/dev/null; done
sleep 2
# bounded: at most 2 launches (fresh-open crash workaround), stop as soon as it paints
for t in 1 2; do
  grep -q "painted" /media/internal/jihad/integ-d.log 2>/dev/null && break
  luna-send -n 1 palm://com.palm.applicationManager/launch "$P" >/dev/null 2>&1
  sleep 11
done
sleep 2
echo "=== paints (mZoom is the tell: 1.0=fixed, 1.333=still looping) ==="
grep painted /media/internal/jihad/integ-d.log | tail -5
