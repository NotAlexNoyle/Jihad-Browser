#!/bin/sh
ls -la /usr/lib/libpbnjson*.so* /usr/lib/libPDL* /usr/lib/libnapp* /usr/lib/libAdapterBase* 2>/dev/null
find /usr/include -name 'npupp.h' -o -name 'npapi.h' 2>/dev/null | head
