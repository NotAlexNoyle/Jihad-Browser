#!/bin/sh
echo "-- Qt headers on device --"; ls -d /usr/include/Qt* /usr/include/qt* 2>/dev/null | head
echo "-- QImage header --"; find /usr/include -name 'QImage' -o -name 'qimage.h' 2>/dev/null | head
echo "-- webkit/npapi headers --"; find /usr/include -path '*npapi*' 2>/dev/null | head
echo "-- Qt libs --"; ls /usr/lib/libQtGui.so* /usr/lib/libQtCore.so* 2>/dev/null
