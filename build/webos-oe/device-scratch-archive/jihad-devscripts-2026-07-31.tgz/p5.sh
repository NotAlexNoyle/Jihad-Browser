#!/bin/sh
find /usr/include -name 'nppalmdefs.h' -o -name 'npupp.h' 2>/dev/null | head
