echo "=== google paint sizes (bytes = non-white pixels; ~700k=full, ~10k=blank) ==="
grep -aE "painted shmid" /media/internal/jihad/upstart-daemon.log 2>/dev/null | tail -12
echo "=== any JS/render errors / OOM / abort ==="
grep -aiE "out of memory|OOM|abort|assertion|MOZ_CRASH|NS_ERROR|prototype|SecurityError|blocked" /media/internal/jihad/upstart-daemon.log 2>/dev/null | tail -10
