#!/bin/sh
echo "=== likely webkit plugin cache locations ==="
for d in /var/luna/data /var/palm/data /var/home /home/root /var/luna; do
  find "$d" -maxdepth 4 \( -iname '*plugin*' -o -iname 'pluginreg*' -o -iname '*.plugins' \) 2>/dev/null | head
done
echo "=== env: where does LunaSysMgr look? grep its config for BrowserPlugins ==="
grep -rlia 'BrowserPlugins' /etc/palm /usr/palm 2>/dev/null | head
echo "=== the isis/luna webkit plugin path setting ==="
grep -rhia 'BrowserPlugins\|PluginPath\|plugindir' /etc/palm/luna.conf /etc/palm/*.conf 2>/dev/null | head
