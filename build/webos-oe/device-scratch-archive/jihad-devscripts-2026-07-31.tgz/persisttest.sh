#!/bin/sh
D=/media/internal/jihad
echo "before: instances=$(ps -ef | grep -c '[l]d-2.23.so') socket=$(ls /tmp/yapserver.browser 2>/dev/null && echo yes)"
P1=$(ps -ef | grep '[l]d-2.23.so' | awk '{print $2}' | head -1)
echo "--- simulate crash: kill daemon ---"
kill -9 $P1 2>/dev/null
sleep 5
P2=$(ps -ef | grep '[l]d-2.23.so' | awk '{print $2}' | head -1)
echo "after crash+5s: instances=$(ps -ef | grep -c '[l]d-2.23.so') newpid=$P2 (oldpid=$P1)"
[ -n "$P2" ] && [ "$P2" != "$P1" ] && echo "UPSTART RESPAWNED IT -> PERSISTENT ✓" || echo "not respawned"
echo "socket: $(ls /tmp/yapserver.browser 2>/dev/null && echo present)"
