#!/bin/sh
echo "=== log lines about plugin loading / jihad adapter / unsupported MIME (last 5 min) ==="
grep -aiE 'BrowserAdapterJihad|x-jihad-browser|npapi|loadPlugin|createPlugin|unsupported.*mime|no plugin|MIME type|pluginForMIME' /var/log/messages 2>/dev/null | tail -25
echo "=== stock adapter load lines (for comparison) ==="
grep -aiE 'BrowserAdapter\.so|x-palm-browser|BrowserAdapterMojo' /var/log/messages 2>/dev/null | tail -6
echo "=== any adapter stderr (adapter fprintf to /media/internal/jihad) ==="
ls -la /media/internal/jihad/adapter*.log 2>/dev/null
