#!/bin/sh
echo "-- WebKit plugin dirs --"
ls -la /usr/lib/BrowserPlugins/ 2>/dev/null
ls -la /usr/palm/BrowserPlugins/ 2>/dev/null
echo "-- symlinks/refs to jihad adapter --"
find /usr/lib/BrowserPlugins /usr/palm -lname '*jihad*' 2>/dev/null
find /usr /var/palm -name '*.so' 2>/dev/null | xargs -r grep -l 'x-jihad-browser' 2>/dev/null | head
echo "-- env WEBKIT_PLUGIN_PATH in luna env --"
grep -rh 'PLUGIN_PATH\|BrowserPlugins\|jihad' /etc/event.d/LunaSysMgr /etc/init/LunaSysMgr* 2>/dev/null | grep -iE 'plugin|jihad' | head
echo "-- what dir has our adapter symlinked/copied --"
find / -name 'BrowserAdapterJihad.so' 2>/dev/null
