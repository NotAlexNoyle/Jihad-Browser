#!/bin/sh
# runs ON DEVICE after boot
echo "=== uptime ==="; uptime 2>/dev/null
echo "=== daemons auto-started? ==="
echo " stock BrowserServer: $(ps -eo comm 2>/dev/null | grep -cx BrowserServer)"
echo " jihad daemon       : $(ps -ef 2>/dev/null | grep -c '[j]ihad-browserserver')"
echo "=== sockets ==="; ls /tmp/yapserver.* 2>/dev/null | tr '\n' ' '; echo
echo "=== adapter present ==="; ls -la /usr/lib/BrowserPlugins/BrowserAdapterJihad.so 2>/dev/null | awk '{print $5,$NF}'
echo "=== jihad upstart job present ==="; ls /etc/event.d/jihad 2>/dev/null && echo present
echo "=== loadavg ==="; cut -d' ' -f1-3 /proc/loadavg
