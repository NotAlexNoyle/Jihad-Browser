#!/bin/sh
D=/media/internal/jihad
echo "up:$(cut -d. -f1 /proc/uptime)s daemon:$(ps -ef 2>/dev/null|grep -c '[j]ihad-browserserver') md5:$(md5sum $D/hl/jihad-browserserver 2>/dev/null|cut -d' ' -f1) socket:$(ls /tmp/yapserver.jihad-browser 2>/dev/null||echo NONE)"
# load input+link test page fresh
luna-send -n 1 palm://com.palm.applicationManager/launch '{"id":"net.riverstonerelay.jihad-browser","params":{"target":"data:text/html,<body style=font-size:38px><input placeholder=tap-here style=font-size:38px;width:90%25><br><br><a href=http://example.net/>go-example-net</a></body>"}}' 2>&1 | head -1
sleep 8
echo "loaded: $(grep -a 'load done uri=' $D/upstart-daemon.log 2>/dev/null|tail -1|cut -c1-40) load:$(cut -d' ' -f1-3 /proc/loadavg)"
