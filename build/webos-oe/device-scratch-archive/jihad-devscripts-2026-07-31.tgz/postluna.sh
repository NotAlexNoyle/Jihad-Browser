#!/bin/sh
D=/media/internal/jihad
sleep 25
: > $D/adapter.log
echo "adapter .so now mapped by:"
for p in /proc/[0-9]*; do grep -q 'BrowserAdapterJihad.so' "$p/maps" 2>/dev/null && echo "  pid=$(basename $p)"; done
echo "md5 of mapped file:"; md5sum /media/internal/jihad/BrowserAdapterJihad.so
luna-send -n 1 palm://com.palm.applicationManager/launch '{"id":"net.riverstonerelay.jihad-browser","params":{"target":"data:text/html,<meta name=viewport content=width=device-width><body style=background:%23bbddff;font-size:40px;padding:30px>Tap box, then type:<br><br><input style=font-size:36px;width:85%25;padding:12px;background:white></body>"}}' 2>/dev/null | head -1
sleep 10
echo "=== [hp] count (NONZERO = NEW adapter loaded) ==="; grep -ac '\[hp\]' $D/adapter.log
grep -a '\[hp\]' $D/adapter.log | tail -2
echo "=== daemon last paint ==="; grep -a painted $D/upstart-daemon.log | tail -1
