GJ=/media/internal/jihad/hl/goanna.js
if grep -q 'JIHAD low-RAM tuning' "$GJ" 2>/dev/null; then echo "prefs already present"; else
cat >> "$GJ" <<'P'
// --- JIHAD low-RAM tuning (512 MB floor) ---
pref("image.mem.surfacecache.max_size_kb", 32768);
pref("image.mem.surfacecache.size_factor", 8);
pref("image.mem.surfacecache.discard_factor", 1);
pref("image.mem.discardable", true);
pref("image.mem.animated.discardable", true);
pref("browser.sessionhistory.max_total_viewers", 0);
pref("browser.sessionhistory.max_entries", 20);
pref("browser.cache.memory.enable", true);
pref("browser.cache.memory.capacity", 16384);
pref("layout.frame_rate", 30);
pref("general.smoothScroll", false);
pref("image.animation_mode", "once");
pref("nglayout.initialpaint.delay", 100);
P
echo "prefs appended"; fi
grep -c 'JIHAD low-RAM tuning' "$GJ"
