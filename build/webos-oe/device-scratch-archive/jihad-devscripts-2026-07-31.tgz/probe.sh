#!/bin/sh
echo "===== stock BrowserServer binary ====="
ls -la /usr/bin/BrowserServer* 2>/dev/null
echo "===== running browser processes ====="
ps -ef 2>/dev/null | grep -iE 'browser|Browser' | grep -v grep
echo "===== BrowserServer launch config (upstart/init) ====="
ls -la /etc/event.d/ 2>/dev/null | grep -iE 'browser'
cat /etc/event.d/BrowserServer 2>/dev/null
ls /etc/init/ 2>/dev/null | grep -iE 'browser'
echo "===== BrowserAdapter NPAPI plugin ====="
find /usr/lib /usr/palm -iname '*BrowserAdapter*' 2>/dev/null | head
ls -la /usr/lib/BrowserPlugins/ 2>/dev/null
echo "===== liblunaservice (for building the daemon w/ Luna) ====="
ls -la /usr/lib/liblunaservice* /usr/lib/libLunaService* 2>/dev/null
echo "===== YAP socket name / how adapter connects ====="
ls -la /tmp/*ap* /var/run/*rowser* 2>/dev/null
echo "===== luna service registration for browserServer ====="
ls /usr/share/dbus-1/services/ 2>/dev/null | grep -iE 'browser'
cat /usr/share/dbus-1/services/com.palm.browserServer* 2>/dev/null
