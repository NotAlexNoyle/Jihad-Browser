#!/bin/sh
echo "===== Jihad UI appinfo ====="
cat /media/cryptofs/apps/usr/palm/applications/net.riverstonerelay.jihad/appinfo.json 2>/dev/null | head -30
echo "===== launch tooling ====="
which luna-send palm-launch 2>/dev/null
ls /usr/bin/luna-send 2>/dev/null
echo "===== BrowserServer upstart conf (to stop stock cleanly) ====="
cat /etc/event.d/browserserver 2>/dev/null
echo "===== screenshot capability ====="
ls /usr/bin/screencapture /usr/bin/luna-send 2>/dev/null; ls /dev/fb0 2>/dev/null
