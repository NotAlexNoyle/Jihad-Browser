#!/bin/sh
echo "=== all sh + jihad processes ==="
ps -ef 2>/dev/null | grep -iE 'keepalive|jihad-browserserver' | grep -v grep
echo "=== keepalive.on ==="
ls -la /media/internal/jihad/keepalive.on 2>/dev/null || echo "absent"
echo "=== sup log ==="
cat /media/internal/jihad/keepalive-sup.log 2>/dev/null | tail -4
