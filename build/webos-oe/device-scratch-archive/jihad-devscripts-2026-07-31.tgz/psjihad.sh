#!/bin/sh
echo "supervisor: $(ps -ef | grep keepalive.sh | grep -vc grep)"
echo "daemon: $(ps -ef | grep jihad-browserserver | grep -vc grep)"
