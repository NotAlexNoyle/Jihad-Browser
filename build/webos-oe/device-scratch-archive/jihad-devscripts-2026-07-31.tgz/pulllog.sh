#!/bin/sh
D=/media/internal/jihad
echo "=== last 25 daemon lines ==="
tail -25 $D/upstart-daemon.log | grep -aE 'editorFocused|insertStr|InsertText|keyDown|vkb tag|painted|clickAt|connect'
echo "=== jihad card + daemon ==="
luna-send -n 1 palm://com.palm.applicationManager/running '{}' 2>/dev/null | tr '{' '\n' | grep -c jihad-browser
echo "daemon: $(ps -ef|grep '[j]ihad-browserserver'|awk '{print $2}'|head -1)"
