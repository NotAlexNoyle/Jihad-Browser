#!/bin/sh
D=/media/internal/jihad
echo "=== raw log: all clickAt + vkb lines in sequence (last 20) ==="
grep -aE 'clickAt \(|vkb |editorFocused' "$D/upstart-daemon.log" 2>/dev/null | tail -20
echo "=== running daemon (confirm 8c69693) ==="
echo "pid:$(ps -ef|grep '[j]ihad-browserserver'|awk '{print $2}'|head -1) file-md5:$(md5sum $D/hl/jihad-browserserver 2>/dev/null|cut -d' ' -f1)"
