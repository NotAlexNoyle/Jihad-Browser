#!/bin/sh
grep -iE 'NSS|loaderr|load done|painted|engine up|openurl' /media/internal/jihad/od-d.log | grep -vi fontconfig | tail -10
