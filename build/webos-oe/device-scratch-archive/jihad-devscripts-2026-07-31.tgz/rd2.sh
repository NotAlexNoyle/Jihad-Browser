#!/bin/sh
grep -iE 'NSS_NoDB|PRerr|InitializeNSS|loaderr|load done' /media/internal/jihad/od-d.log 2>/dev/null | tail -6
