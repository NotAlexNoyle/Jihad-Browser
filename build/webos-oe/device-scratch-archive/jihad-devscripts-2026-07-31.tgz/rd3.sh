#!/bin/sh
grep -iE 'engine up|PRerr|NoDB|panick|softokn|freebl|library' /media/internal/jihad/od-d.log 2>/dev/null | grep -vi fontconfig | tail -6
