#!/bin/sh
grep -iE 'InitializeNSS OK|openurl|load done|loaderr|painted' /media/internal/jihad/od-d.log 2>/dev/null | tail -6
