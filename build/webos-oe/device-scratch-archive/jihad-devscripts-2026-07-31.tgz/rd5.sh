#!/bin/sh
grep -iE 'setUserAgent|useragent|user agent|daemon up|engine up' /media/internal/jihad/integ-d.log 2>/dev/null | grep -vi fontconfig | tail -6
echo "--- goanna.js override present on device? ---"
grep useragent.override /media/internal/jihad/hl/goanna.js 2>/dev/null | head -1
