#!/bin/sh
echo "rebooting for clean plugin scan..."
sync
/sbin/reboot 2>/dev/null || reboot 2>/dev/null
