#!/bin/sh
sync
# try luna power reboot first
luna-send -n 1 palm://com.palm.power/shutdown/machineReboot '{"reason":"jihad"}' >/dev/null 2>&1
# detached hard fallback in case the above is ignored
nohup sh -c 'sleep 3; /sbin/reboot; sleep 5; echo b > /proc/sysrq-trigger' >/dev/null 2>&1 &
echo "reboot requested (up was $(cut -d. -f1 /proc/uptime)s)"
