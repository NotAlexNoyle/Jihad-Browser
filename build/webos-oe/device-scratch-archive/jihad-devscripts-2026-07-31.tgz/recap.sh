#!/bin/sh
D=/media/internal/jihad
dd if=/dev/fb1 of="$D/fb1now.bgra" bs=4096 count=768 2>/dev/null
echo "captured $(wc -c < $D/fb1now.bgra) bytes; last paint: $(grep -a painted $D/upstart-daemon.log 2>/dev/null | tail -1 | sed 's/.*bytes=/bytes=/')"
