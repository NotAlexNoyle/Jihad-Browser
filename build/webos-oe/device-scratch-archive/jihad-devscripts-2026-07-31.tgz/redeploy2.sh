#!/bin/sh
D=/media/internal/jihad
echo "device md5:"; md5sum $D/BrowserAdapterJihad.so | cut -c1-12
chmod 777 $D/BrowserAdapterJihad.so
: > $D/adapter.log
killall LunaSysMgr 2>/dev/null
i=0; while [ $i -lt 30 ]; do sleep 3; NP=$(pidof LunaSysMgr); [ -n "$NP" ] && break; i=$((i+1)); done
echo "luna up: $NP; settle..."; sleep 20
: > $D/adapter.log
luna-send -n 1 palm://com.palm.applicationManager/launch '{"id":"net.riverstonerelay.jihad-browser","params":{"target":"data:text/html,<meta name=viewport content=width=device-width><body style=background:%23bbddff;font-size:40px;padding:30px>Tap box, then type:<br><br><input style=font-size:36px;width:85%25;padding:12px;background:white></body>"}}' 2>/dev/null | head -1
sleep 9
echo "=== initial adapter.log ==="; tail -4 $D/adapter.log
