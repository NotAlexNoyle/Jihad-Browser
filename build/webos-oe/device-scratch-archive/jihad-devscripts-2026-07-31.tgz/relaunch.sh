#!/bin/sh
D=/media/internal/jihad
echo "daemon:$(ps -ef|grep '[j]ihad-browserserver'|awk '{print $2}'|head -1)"
echo "app-running-before:"; luna-send -n 1 palm://com.palm.applicationManager/running '{}' 2>/dev/null | sed 's/},{/}\n{/g' | grep -i jihad | head -1
luna-send -n 1 palm://com.palm.applicationManager/launch '{"id":"net.riverstonerelay.jihad-browser","params":{"target":"data:text/html,<meta name=viewport content=width=device-width><body style=background:%23bbddff;font-size:40px;padding:30px>Tap box, then type:<br><br><input style=font-size:36px;width:85%25;padding:12px;background:white></body>"}}' 2>&1 | head -1
sleep 6
echo "app-running-after:"; luna-send -n 1 palm://com.palm.applicationManager/running '{}' 2>/dev/null | sed 's/},{/}\n{/g' | grep -i jihad | head -1
echo "app-log-tail:"; tail -8 $D/upstart-daemon.log 2>/dev/null | grep -aiE 'load|error|abort|painted' | tail -4
