#!/bin/sh
echo "=== before: daemons + loadavg ==="
echo " stock BS  : $(ps -ef 2>/dev/null | grep -c '[/]usr/bin/BrowserServer')  jihad: $(ps -ef 2>/dev/null | grep -c '[j]ihad-browserserver')"
echo " loadavg   : $(cut -d' ' -f1-3 /proc/loadavg)"
echo "=== reload LunaSysMgr (upstart respawns it -> re-scans /usr/lib/BrowserPlugins) ==="
killall LunaSysMgr 2>/dev/null
echo "waiting for LunaSysMgr to come back..."
i=0
while [ $i -lt 30 ]; do
  sleep 2
  P=$(ps -ef 2>/dev/null | grep -c '[L]unaSysMgr')
  if [ "$P" -ge 1 ]; then echo "LunaSysMgr back after ~$((i*2+2))s"; break; fi
  i=$((i+1))
done
sleep 3
echo "=== after: health ==="
echo " LunaSysMgr: $(ps -ef 2>/dev/null | grep -c '[L]unaSysMgr')"
echo " stock BS  : $(ps -ef 2>/dev/null | grep -c '[/]usr/bin/BrowserServer')  jihad: $(ps -ef 2>/dev/null | grep -c '[j]ihad-browserserver')"
echo " jihad sock: $(ls /tmp/yapserver.jihad-browser 2>/dev/null || echo NONE)"
echo " loadavg   : $(cut -d' ' -f1-3 /proc/loadavg)"
