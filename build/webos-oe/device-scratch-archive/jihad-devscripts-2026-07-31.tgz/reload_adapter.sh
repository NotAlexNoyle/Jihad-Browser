#!/bin/sh
D=/media/internal/jihad
: > $D/adapter.log
# fully close the jihad app card (frees the plugin .so)
CP=$(luna-send -n 1 palm://com.palm.applicationManager/running '{}' 2>/dev/null | sed 's/},{/}\n{/g' | grep -i jihad-browser | grep -oiE 'processid[": ]+[0-9]+' | grep -oE '[0-9]+' | head -1)
echo "closing card processId=$CP"
[ -n "$CP" ] && luna-send -n 1 palm://com.palm.applicationManager/close "{\"processId\":\"$CP\"}" 2>/dev/null >/dev/null
sleep 4
# relaunch with blue page
luna-send -n 1 palm://com.palm.applicationManager/launch '{"id":"net.riverstonerelay.jihad-browser","params":{"target":"data:text/html,<meta name=viewport content=width=device-width><body style=background:%23bbddff;font-size:40px;padding:30px>Tap box, then type:<br><br><input style=font-size:36px;width:85%25;padding:12px;background:white></body>"}}' 2>/dev/null | head -1
sleep 9
echo "=== adapter.log [hp] count (NONZERO = new adapter loaded) ==="
grep -ac '\[hp\]' $D/adapter.log
echo "=== sample [hp] ==="; grep -a '\[hp\]' $D/adapter.log | tail -2
echo "=== daemon last paint ==="; grep -a painted $D/upstart-daemon.log | tail -2
