#!/bin/sh
D=/media/internal/jihad
echo "=== recent paints (input page: bytes>0 = rendered) ==="
grep -a 'painted' "$D/upstart-daemon.log" 2>/dev/null | tail -8
echo "=== emitGeometry (contentSize) ==="
grep -a 'emitGeometry' "$D/upstart-daemon.log" 2>/dev/null | tail -5
echo "=== load done ==="
grep -a 'load done uri=' "$D/upstart-daemon.log" 2>/dev/null | tail -2 | cut -c1-40
echo "daemon-pid:$(ps -ef|grep '[j]ihad-browserserver'|awk '{print $2}'|head -1) load:$(cut -d' ' -f1 /proc/loadavg)"
