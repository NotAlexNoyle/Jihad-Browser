#!/bin/sh
D=/media/internal/jihad
: > $D/adapter.log
CP=$(luna-send -n 1 palm://com.palm.applicationManager/running '{}' 2>/dev/null | tr '{' '\n' | grep 'jihad-browser' | grep -oE 'processid[^0-9]*[0-9]+' | grep -oE '[0-9]+' | head -1)
[ -n "$CP" ] && luna-send -n 1 palm://com.palm.applicationManager/close "{\"processId\":\"$CP\"}" 2>/dev/null >/dev/null
sleep 4
# simple opaque page: solid red top band + green bottom band, big text, to see alignment/scale
luna-send -n 1 palm://com.palm.applicationManager/launch '{"id":"net.riverstonerelay.jihad-browser","params":{"target":"data:text/html,<meta name=viewport content=width=device-width><body style=margin:0><div style=height:200px;background:%23ff0000>RED TOP</div><div style=height:200px;background:%2300ff00>GREEN</div><div style=height:200px;background:%230000ff;color:white>BLUE</div></body>"}}' 2>/dev/null | head -1
sleep 10
dd if=/dev/fb1 of=$D/fbrender.bgra bs=4096 count=768 2>/dev/null
echo "=== daemon paints ==="; grep -a painted $D/upstart-daemon.log | tail -3
echo "=== adapter hp blits ==="; grep -a '\[hp\]' $D/adapter.log | tail -4
echo "daemon:$(ps -ef|grep '[j]ihad-browserserver'|awk '{print $2}'|head -1)"
