#!/bin/sh
D=/media/internal/jihad
sleep 3
touch $D/adapterlog   # enable gated paint logging
: > $D/adapter.log
luna-send -n 1 palm://com.palm.applicationManager/launch '{"id":"net.riverstonerelay.jihad-browser","params":{"target":"data:text/html,<meta name=viewport content=width=device-width><body style=margin:0><div style=height:200px;background:%23ff0000>RED TOP</div><div style=height:200px;background:%2300ff00>GREEN</div><div style=height:200px;background:%230000ff;color:white>BLUE</div></body>"}}' 2>/dev/null | head -1
sleep 10
dd if=/dev/fb1 of=$D/fbr.bgra bs=4096 count=768 2>/dev/null
echo "shim: $(tail -1 $D/shim.log)"
echo "daemon paint: $(grep -a painted $D/upstart-daemon.log | tail -1)"
echo "hp: $(grep -a '\[hp\]' $D/adapter.log | tail -1)"
