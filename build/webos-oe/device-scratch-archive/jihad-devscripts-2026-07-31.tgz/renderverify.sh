#!/bin/sh
D=/media/internal/jihad
/sbin/stop jihad 2>/dev/null; sleep 2; /sbin/start jihad 2>/dev/null; sleep 3
CP=$(luna-send -n 1 palm://com.palm.applicationManager/running '{}' 2>/dev/null | sed 's/},{/}\n{/g' | grep -i jihad | grep -oiE 'processid[": ]+[0-9]+' | grep -oE '[0-9]+' | head -1)
[ -n "$CP" ] && luna-send -n 1 palm://com.palm.applicationManager/close "{\"processId\":\"$CP\"}" 2>/dev/null >/dev/null
sleep 2
DLOG=$(wc -l < "$D/upstart-daemon.log" 2>/dev/null || echo 0)
luna-send -n 1 palm://com.palm.applicationManager/launch '{"id":"net.riverstonerelay.jihad-browser","params":{"target":"http://example.com/"}}' 2>&1 | head -1
sleep 12
echo "running daemon md5: $(md5sum $D/hl/jihad-browserserver 2>/dev/null|cut -d' ' -f1) (expect 82ccb50...)"
echo "=== paints on FIRST load (bytes>0 on the first paint = black-card fixed) ==="
tail -n +$((DLOG+1)) "$D/upstart-daemon.log" 2>/dev/null | grep -aiE 'load done|painted .*bytes' | tail -8
echo "load:$(cut -d' ' -f1-3 /proc/loadavg)"
