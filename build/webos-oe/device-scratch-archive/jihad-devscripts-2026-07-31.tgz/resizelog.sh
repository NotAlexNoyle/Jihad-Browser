#!/bin/sh
D=/media/internal/jihad
grep -aiE 'editorFocused|setWindowSize|Resize|emitGeometry|painted .*bytes|contentSize' "$D/upstart-daemon.log" 2>/dev/null | tail -22
echo "daemon-pid:$(ps -ef|grep '[j]ihad-browserserver'|awk '{print $2}'|head -1) load:$(cut -d' ' -f1 /proc/loadavg)"
