#!/bin/sh
/sbin/stop browserserver 2>/dev/null
sleep 1
: > /media/internal/jihad/upstart-daemon.log
/sbin/start browserserver 2>&1 | tail -1
sleep 3
echo "serving: $(grep -c "serving YAP 'browser'" /media/internal/jihad/upstart-daemon.log)"
echo "socket: $(ls /tmp/yapserver.browser 2>/dev/null && echo present)"
