#!/bin/sh
/sbin/stop jihad 2>/dev/null
sleep 2
/sbin/start jihad 2>/dev/null
sleep 4
echo " daemon: $(ps -ef 2>/dev/null | grep -c '[j]ihad-browserserver')  socket: $(ls /tmp/yapserver.jihad-browser 2>/dev/null || echo NONE)  load: $(cut -d' ' -f1 /proc/loadavg)"
echo " running md5: $(md5sum /media/internal/jihad/hl/jihad-browserserver 2>/dev/null | cut -d' ' -f1)"
