#!/bin/sh
D=/media/internal/jihad
: > $D/adapter.log
echo "old LunaSysMgr pid: $(pidof LunaSysMgr)"
killall LunaSysMgr 2>/dev/null
echo "killed, waiting for respawn..."
i=0
while [ $i -lt 30 ]; do
  sleep 3
  NP=$(pidof LunaSysMgr)
  [ -n "$NP" ] && { echo "new LunaSysMgr pid: $NP (after $((i*3))s)"; break; }
  i=$((i+1))
done
