#!/bin/sh
D=/media/internal/jihad
mount -o remount,rw / 2>/dev/null
echo "=== restore stock browserserver upstart job ==="
/sbin/stop browserserver 2>/dev/null
if [ -f "$D/browserserver.stock.bak" ]; then
  cp "$D/browserserver.stock.bak" /etc/event.d/browserserver
  echo "restored stock job: $(grep -c '/usr/bin/BrowserServer' /etc/event.d/browserserver)"
fi
echo "=== restore stock BrowserAdapter.so (if my replacement is there) ==="
if [ -f /usr/lib/BrowserPlugins/BrowserAdapter.so.stock ]; then
  cp /usr/lib/BrowserPlugins/BrowserAdapter.so.stock /usr/lib/BrowserPlugins/BrowserAdapter.so
  echo "restored stock adapter: $(ls -la /usr/lib/BrowserPlugins/BrowserAdapter.so | awk '{print $5}') bytes"
fi
echo "=== ensure my jihad daemon binary is not in the crash-loop path ==="
ls "$D/hl/jihad-browserserver"* 2>/dev/null | xargs -n1 basename 2>/dev/null | tr '\n' ' '; echo
echo "=== event.d browser jobs (should be browserserver+mojo, no stray) ==="
ls /etc/event.d/ | grep -i brows | tr '\n' ' '; echo
echo "loadavg: $(cat /proc/loadavg | cut -d' ' -f1-3)"
