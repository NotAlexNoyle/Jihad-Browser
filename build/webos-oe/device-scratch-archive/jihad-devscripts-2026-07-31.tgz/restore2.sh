#!/bin/sh
BP=/usr/lib/BrowserPlugins
echo "== restore stock adapter =="
mount -o remount,rw / 2>/dev/null
[ -f "$BP/BrowserAdapter.so.stock" ] && cp "$BP/BrowserAdapter.so.stock" "$BP/BrowserAdapter.so" && echo "  stock adapter restored"
echo "== kill Jihad daemon, restart stock BrowserServer =="
/usr/bin/pkill -9 -f 'jihad-browserserver' 2>/dev/null
rm -f /tmp/yapserver.browser
/sbin/start browserserver 2>&1 | tail -1
sleep 3
ps -ef 2>/dev/null | grep -E '/usr/bin/BrowserServer -d' | grep -v grep | head -1
echo "  device restored to stock"
