#!/bin/sh
mount -o remount,rw / 2>/dev/null
/sbin/stop browserserver 2>/dev/null; /usr/bin/pkill -9 -f jihad-browserserver 2>/dev/null; sleep 2
cp /media/internal/jihad/browserserver.jihad /etc/event.d/browserserver
: > /media/internal/jihad/upstart-daemon.log
/sbin/start browserserver 2>&1 | tail -1
sleep 5
echo "=== upstart-daemon.log ==="
grep -viE 'Fontconfig' /media/internal/jihad/upstart-daemon.log | tail -15
echo "=== instances now: $(ps -ef | grep -c '[l]d-2.23.so') ==="
