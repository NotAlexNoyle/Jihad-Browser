#!/bin/sh
luna-send -n 1 -a net.riverstonerelay.jihad-browser luna://com.palm.db/find "{\"query\":{\"from\":\"net.riverstonerelay.jihad-browser.history:1\",\"orderBy\":\"date\"}}"
