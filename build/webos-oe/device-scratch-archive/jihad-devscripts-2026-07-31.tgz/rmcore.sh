#!/bin/sh
rm -f /media/internal/jihad/cores/core.ld-2.23.so.*
ls /media/internal/jihad/cores/
