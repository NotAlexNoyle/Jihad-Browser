#!/bin/sh
cd /media/internal/jihad/goanna
chmod 755 ld-2.23.so jihad-browserserver jihad-adapter-arm 2>/dev/null
export JIHAD_OFFSCREEN=1
export JIHAD_DISABLE_OMTC=1
export FONTCONFIG_PATH=/etc/fonts
./ld-2.23.so --library-path /media/internal/jihad/goanna ./jihad-browserserver /media/internal/jihad/goanna >/media/internal/jihad/d.log 2>&1 &
DP=$!
sleep 9
./ld-2.23.so --library-path /media/internal/jihad/goanna ./jihad-adapter-arm >/media/internal/jihad/a.log 2>&1
sleep 1
kill $DP 2>/dev/null
echo "=== ADAPTER (render round-trip) ==="
cat /media/internal/jihad/a.log
