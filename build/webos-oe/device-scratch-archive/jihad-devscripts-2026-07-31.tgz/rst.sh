#!/bin/sh
stop jihad 2>/dev/null; sleep 1; start jihad; sleep 2; cat /proc/sys/kernel/core_pattern
