#!/bin/sh
# Extract + run the HEADLESS (GTK/X-free) Jihad bundle on-device, offscreen round-trip.
cd /media/internal/jihad
rm -rf hl && mkdir hl
tar xzf hl-bundle.tar.gz -C hl 2>/dev/null
cd hl
chmod 755 ld-2.23.so jihad-browserserver jihad-adapter-arm 2>/dev/null
export JIHAD_OFFSCREEN=1
export JIHAD_DISABLE_OMTC=1
export FONTCONFIG_PATH=/etc/fonts
rm -f /media/internal/jihad/hl-d.log /media/internal/jihad/hl-a.log /media/internal/jihad/hl.done
(
  ./ld-2.23.so --library-path /media/internal/jihad/hl ./jihad-browserserver /media/internal/jihad/hl >/media/internal/jihad/hl-d.log 2>&1 &
  DP=$!
  sleep 16
  ./ld-2.23.so --library-path /media/internal/jihad/hl ./jihad-adapter-arm >/media/internal/jihad/hl-a.log 2>&1 &
  AP=$!
  sleep 26
  kill -9 $AP $DP 2>/dev/null
  /usr/bin/pkill -9 jihad-browser 2>/dev/null
  echo done > /media/internal/jihad/hl.done
) &
echo "hl round-trip launched (detached)"
