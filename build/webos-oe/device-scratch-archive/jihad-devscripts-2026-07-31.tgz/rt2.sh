#!/bin/sh
cd /media/internal/jihad/goanna
chmod 755 ld-2.23.so jihad-browserserver jihad-adapter-arm 2>/dev/null
export JIHAD_OFFSCREEN=1
export JIHAD_DISABLE_OMTC=1
export FONTCONFIG_PATH=/etc/fonts
rm -f /media/internal/jihad/d.log /media/internal/jihad/a.log /media/internal/jihad/rt.done
(
  ./ld-2.23.so --library-path /media/internal/jihad/goanna ./jihad-browserserver /media/internal/jihad/goanna >/media/internal/jihad/d.log 2>&1 &
  DP=$!
  sleep 14
  ./ld-2.23.so --library-path /media/internal/jihad/goanna ./jihad-adapter-arm >/media/internal/jihad/a.log 2>&1 &
  AP=$!
  sleep 22
  kill -9 $AP $DP 2>/dev/null
  /usr/bin/pkill -9 jihad-browser 2>/dev/null
  echo done > /media/internal/jihad/rt.done
) &
echo "round-trip launched (detached)"
