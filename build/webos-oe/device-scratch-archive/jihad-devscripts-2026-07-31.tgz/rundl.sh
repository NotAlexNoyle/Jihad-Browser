#!/bin/sh
chmod 755 /media/internal/jihad/dltest
export LD_LIBRARY_PATH=/usr/lib:/lib
/media/internal/jihad/dltest 2>&1
echo "exit=$?"
