#!/bin/sh
# wait for boot to settle (idle > 40%) before restarting, to avoid piling on
i=0
while [ $i -lt 12 ]; do
  ID=$(top -bn1 2>/dev/null | sed -n '3p' | grep -oE '[0-9.]+%id' | grep -oE '^[0-9]+')
  [ -n "$ID" ] && [ "$ID" -gt 40 ] && break
  sleep 5; i=$((i+1))
done
echo "settled at idle=${ID}% after ~$((i*5))s"
/sbin/stop jihad 2>/dev/null; sleep 2; /sbin/start jihad 2>/dev/null; sleep 3
echo "daemon:$(ps -ef 2>/dev/null|grep -c '[j]ihad-browserserver') socket:$(ls /tmp/yapserver.jihad-browser 2>/dev/null||echo NONE)"
echo "running md5: $(md5sum /media/internal/jihad/hl/jihad-browserserver 2>/dev/null | cut -d' ' -f1)"
echo "load: $(cut -d' ' -f1-3 /proc/loadavg)"
