#!/bin/sh
D=/media/internal/jihad
echo "daemon md5: $(md5sum $D/hl/jihad-browserserver | cut -c1-12) (expect 197588c9)"
chmod 755 $D/hl/jihad-browserserver
/sbin/stop jihad 2>/dev/null; sleep 2; /sbin/start jihad 2>/dev/null; sleep 4
PID0=$(ps -ef|grep '[j]ihad-browserserver'|awk '{print $2}'|head -1)
echo "daemon PID0=$PID0"
MARK=$(wc -l < $D/upstart-daemon.log)
luna-send -n 1 palm://com.palm.applicationManager/launch '{"id":"net.riverstonerelay.jihad-browser","params":{"target":"data:text/html,<!--jihadselftest--><meta name=viewport content=width=device-width><body style=font-size:40px;padding:20px>selftest<br><input style=font-size:36px;width:80%25></body>"}}' 2>/dev/null | head -1
sleep 12
PID1=$(ps -ef|grep '[j]ihad-browserserver'|awk '{print $2}'|head -1)
echo "daemon PID1=$PID1 $([ "$PID0" = "$PID1" ] && echo STABLE || echo CRASHED)"
echo "=== SELFTEST trace (last line before any crash = crash site) ==="
tail -n +$((MARK+1)) $D/upstart-daemon.log | grep -aE 'SELFTEST|engine up' | tail -20
