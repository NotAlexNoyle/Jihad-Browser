#!/bin/sh
mkdir -p /media/internal/jihad/cores
echo '/media/internal/jihad/cores/core.%e.%p' > /proc/sys/kernel/core_pattern
cat /proc/sys/kernel/core_pattern
