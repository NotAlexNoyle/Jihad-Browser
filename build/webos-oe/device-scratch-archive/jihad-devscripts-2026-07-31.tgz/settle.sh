#!/bin/sh
for i in 1 2 3 4 5; do
  sleep 6
  echo "t+$((i*6))s loadavg=$(cut -d' ' -f1 /proc/loadavg) WebAppMgr=$(ps -eo pcpu,comm 2>/dev/null | grep WebAppMgr | awk '{s+=$1} END{print s}')% top=$(ps -eo pcpu,comm 2>/dev/null | sort -rn | grep -v '^ *%' | head -1 | tr -s ' ')"
done
echo "=== final ==="
echo " loadavg: $(cut -d' ' -f1-3 /proc/loadavg)"
echo " jihad daemon: $(ps -ef 2>/dev/null | grep -c '[j]ihad-browserserver')  stock BS: $(ps -ef 2>/dev/null | grep -c '[/]usr/bin/BrowserServer')  Luna: $(ps -ef 2>/dev/null | grep -c '[L]unaSysMgr')"
