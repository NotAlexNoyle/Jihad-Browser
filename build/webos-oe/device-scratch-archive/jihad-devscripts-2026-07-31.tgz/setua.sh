#!/bin/sh
G=/media/internal/jihad/hl/goanna.js
grep -q 'general.useragent.override' "$G" 2>/dev/null || echo 'pref("general.useragent.override", "Mozilla/5.0 (Linux; U; webOS/3.0.5; hpwOS/3.0.5; TouchPad; rv:52.9) Gecko/20100101 Goanna/4.8 Firefox/52.9 JihadBrowser/1.0");' >> "$G"
echo "UA pref:"; grep 'useragent.override' "$G"
