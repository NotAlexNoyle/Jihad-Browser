#!/bin/sh
G=/media/internal/jihad/hl/goanna.js
grep -v 'general.useragent.override' "$G" > "$G.tmp" && mv "$G.tmp" "$G"
echo 'pref("general.useragent.override", "Mozilla/5.0 (Linux armv7l; U; webOS/3.0.5; hpwOS/3.0.5; TouchPad) Goanna/6.9 UXP/b2594a4 Firefox/52.9 ECMAScript/2024 JihadBrowser/1.0");' >> "$G"
grep useragent.override "$G"
