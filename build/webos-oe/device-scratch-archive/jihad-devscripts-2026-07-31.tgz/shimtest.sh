#!/bin/sh
D=/media/internal/jihad
: > $D/shim.log; : > $D/adapter.log
killall LunaSysMgr 2>/dev/null
i=0; while [ $i -lt 30 ]; do sleep 3; NP=$(pidof LunaSysMgr); [ -n "$NP" ] && break; i=$((i+1)); done
echo "luna up: $NP; settle..."; sleep 22
luna-send -n 1 palm://com.palm.applicationManager/launch '{"id":"net.riverstonerelay.jihad-browser","params":{"target":"data:text/html,<meta name=viewport content=width=device-width><body style=background:%23bbddff;font-size:40px;padding:30px>Tap box, then type:<br><br><input style=font-size:36px;width:85%25;padding:12px;background:white></body>"}}' 2>/dev/null | head -1
sleep 10
echo "=== shim.log (should show 'loaded impl') ==="; cat $D/shim.log
echo "=== adapter.log has [hp-entry]? (proves NEW impl w/ instrumentation) ==="; grep -ac 'hp-entry' $D/adapter.log
echo "=== adapter.log tail ==="; tail -3 $D/adapter.log
echo "=== which .so mapped by luna ==="
for p in /proc/[0-9]*; do grep -q 'BrowserAdapter' "$p/maps" 2>/dev/null && { grep -oE '/[^ ]*BrowserAdapter[A-Za-z]*\.so' "$p/maps" | sort -u; break; }; done
