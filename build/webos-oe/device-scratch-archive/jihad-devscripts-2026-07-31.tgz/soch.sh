#!/bin/sh
S=/usr/lib/BrowserPlugins/BrowserAdapterJihad.so
echo "=== present? ==="; ls -la $S 2>/dev/null | awk '{print $5,$NF}'
echo "=== NPAPI exports ==="; /usr/bin/nm -D $S 2>/dev/null | grep -iE 'NP_Initialize|NP_GetMIMEDescription|NP_GetValue|NP_Shutdown' | head
echo "=== missing deps (ldd) ==="; ldd $S 2>/dev/null | grep -i 'not found' || echo " all deps resolved"
echo "=== compare exports vs stock adapter ==="
/usr/bin/nm -D /usr/lib/BrowserPlugins/BrowserAdapter.so 2>/dev/null | grep -iE 'NP_Initialize|NP_GetMIMEDescription' | head
