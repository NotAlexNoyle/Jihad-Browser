#!/bin/sh
D=/media/internal/jihad
MARK=$(wc -l < $D/upstart-daemon.log)
echo "type ~10 chars now (40s)..."
sleep 40
echo "=== insert vs paint (ms) per keystroke ==="
tail -n +$((MARK+1)) $D/upstart-daemon.log | grep -aoE 'keyDown insert=[0-9]+ms paint=[0-9]+ms' | tail -20
