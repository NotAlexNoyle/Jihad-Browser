#!/bin/sh
# same pid across time = stable; changing = crash-looping
P1=$(ps -ef | grep 'ld-2.23.so' | grep -v grep | awk '{print $2}' | head -1)
echo "pid t=0: $P1"
sleep 4
P2=$(ps -ef | grep 'ld-2.23.so' | grep -v grep | awk '{print $2}' | head -1)
echo "pid t=4: $P2"
[ -n "$P1" ] && [ "$P1" = "$P2" ] && echo "STABLE (same pid, not looping)" || echo "pid changed or gone"
echo "socket: $(ls /tmp/yapserver.browser 2>/dev/null && echo present || echo absent)"
echo "fd1 of daemon: $([ -n "$P2" ] && readlink /proc/$P2/fd/1 2>/dev/null)"
