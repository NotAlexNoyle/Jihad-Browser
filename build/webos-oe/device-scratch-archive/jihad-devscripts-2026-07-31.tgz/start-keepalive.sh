#!/bin/sh
D=/media/internal/jihad
SSD=$(command -v start-stop-daemon || echo /sbin/start-stop-daemon)
rm -f "$D/keepalive.on"
"$SSD" --stop --quiet --name keepalive.sh 2>/dev/null
/usr/bin/pkill -9 -f keepalive.sh 2>/dev/null
/usr/bin/pkill -9 -f jihad-browserserver 2>/dev/null
sleep 2
rm -f /tmp/yapserver.browser*
: > "$D/integ-d.log"
# Daemonize the supervisor properly (new session, detached from novacom).
"$SSD" --start --background --exec /bin/sh -- "$D/keepalive.sh"
echo "start-stop-daemon exit=$?"
