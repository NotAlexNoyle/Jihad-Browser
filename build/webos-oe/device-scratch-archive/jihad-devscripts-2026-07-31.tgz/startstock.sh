#!/bin/sh
echo "=== start stock browserserver (binds /tmp/yapserver.browser) ==="
/sbin/start browserserver 2>&1 | head -2
sleep 5
echo "=== sockets now ==="; ls -la /tmp/yapserver.* 2>/dev/null | awk '{print " ",$NF}'
echo "=== real stock BrowserServer running? ==="
ps -ef 2>/dev/null | grep '[/]usr/bin/BrowserServer ' | head -1 || echo " (checking exact)"
ps -eo pid,comm 2>/dev/null | grep -E 'BrowserServer$' | head
echo "=== instantaneous top (settle check) ==="
sleep 3
ps -eo pcpu,pid,comm 2>/dev/null | sort -rn | head -5
echo " loadavg: $(cut -d' ' -f1-3 /proc/loadavg)"
