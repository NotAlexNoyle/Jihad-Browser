#!/bin/sh
echo "luna maps:"; for p in /proc/[0-9]*; do grep -q 'BrowserAdapter' "$p/maps" 2>/dev/null && { grep -o '/media[^ ]*BrowserAdapter[A-Za-z]*\.so' "$p/maps" | sort -u; break; }; done
echo "deployed md5:"; md5sum /media/internal/jihad/BrowserAdapterJihad.so | cut -c1-12
echo "orientation/rotation:"; luna-send -n 1 palm://com.palm.display/control/status '{}' 2>/dev/null | head -c 200; echo
echo "daemon:$(ps -ef|grep '[j]ihad-browserserver'|awk '{print $2}'|head -1) luna:$(pidof LunaSysMgr|head -c 20)"
dd if=/dev/fb1 of=/media/internal/jihad/fbstate.bgra bs=4096 count=768 2>/dev/null; echo "captured fb1"
