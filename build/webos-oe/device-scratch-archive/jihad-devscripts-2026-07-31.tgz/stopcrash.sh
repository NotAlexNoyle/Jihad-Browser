#!/bin/sh
# stop the respawn so the daemon quits crash-looping
/sbin/stop browserserver 2>/dev/null
rm -f /media/internal/jihad/keepalive.on
/usr/bin/pkill -9 -f keepalive.sh 2>/dev/null
# let the current core dump finish, then kill the daemon so it can't respawn+recrash
sleep 3
/usr/bin/pkill -9 -f jihad-browserserver 2>/dev/null
sleep 2
echo "loadavg: $(cat /proc/loadavg | cut -d' ' -f1-3)"
echo "daemon instances: $(ps -ef | grep -c '[l]d-2.23.so')"
echo "minicore2 running: $(ps -ef | grep -c '[m]inicore2')"
echo "=== core files (for backtrace) ==="
ls -la /var/log/*core* /media/internal/*core* /media/internal/jihad/*core* 2>/dev/null | tail -3
ls -la /proc/sys/kernel/core_pattern 2>/dev/null && cat /proc/sys/kernel/core_pattern 2>/dev/null
