#!/bin/sh
cp /media/internal/jihad/hl/jihad-browserserver.new /media/internal/jihad/hl/jihad-browserserver
stop jihad 2>/dev/null
sleep 1
start jihad
sleep 3
md5sum /media/internal/jihad/hl/jihad-browserserver
