#!/bin/sh
D=/media/internal/jihad
mount -o remount,rw / 2>/dev/null
# install the vetted adapter
cp "$D/BrowserAdapter.so" /usr/lib/BrowserPlugins/BrowserAdapter.so
chmod 755 /usr/lib/BrowserPlugins/BrowserAdapter.so
# stop the stock BrowserServer (spawned on boot) + the upstart job + any jihad daemon
/sbin/stop browserserver 2>/dev/null
/usr/bin/pkill -9 -f '/usr/bin/BrowserServer' 2>/dev/null
/usr/bin/pkill -9 -f jihad-browserserver 2>/dev/null
sleep 2
rm -f /tmp/yapserver.browser*
: > "$D/upstart-daemon.log"
rm -f "$D/adapter.log"
# start MY Jihad daemon via the (jihad) upstart job -> it binds YAP 'browser'
/sbin/start browserserver 2>&1 | tail -1
sleep 4
echo "jihad daemon serving: $(grep -c "serving YAP 'browser'" "$D/upstart-daemon.log")"
echo "jihad daemon instances: $(ps -ef | grep -c '[l]d-2.23.so')"
echo "stock BrowserServer still up: $(ps -ef | grep -c '[/]usr/bin/BrowserServer ')"
echo "socket: $(ls /tmp/yapserver.browser 2>/dev/null && echo present)"
