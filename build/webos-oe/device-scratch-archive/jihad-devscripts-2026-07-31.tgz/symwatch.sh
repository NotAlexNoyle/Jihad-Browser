#!/bin/sh
D=/media/internal/jihad
MARK=$(wc -l < $D/upstart-daemon.log)
echo "tap + type letters & symbols now (45s)..."
sleep 45
dd if=/dev/fb1 of=$D/fbsym.bgra bs=4096 count=768 2>/dev/null
echo "=== per-paint render times (ms) during typing ==="
tail -n +$((MARK+1)) $D/upstart-daemon.log | grep -aoE 'render=[0-9]+ms' | sort | uniq -c | sort -rn | head
echo "=== paint count ==="; tail -n +$((MARK+1)) $D/upstart-daemon.log | grep -ac 'painted'
echo "daemon: $(ps -ef|grep '[j]ihad-browserserver'|awk '{print $2}'|head -1)"
