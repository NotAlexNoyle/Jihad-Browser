#!/bin/sh
B=/usr/palm/frameworks/enyo/0.10/framework/source/palm/controls/BasicWebView.js
echo "=== kind name + MIME in system enyo 0.10 BasicWebView.js ==="
grep -nE 'name:|kind:|x-palm-browser|domAttributes|nodeTag|create:|type' "$B" 2>/dev/null | head -25
echo "=== how depends.js gets loaded (does framework auto-load app depends.js?) ==="
grep -rn 'depends.js\|loadDepends\|_loadScript\|ajax.*depends' /usr/palm/frameworks/enyo/0.10/framework/enyo.js 2>/dev/null | head -5
