#!/bin/sh
D=/media/internal/jihad
echo "=== daemon log: recent click/mouse/state activity ==="
grep -aiE 'clickAt|mouseEvent|MouseEvent|state top|load done|START' "$D/upstart-daemon.log" 2>/dev/null | tail -20
echo "=== adapter.log: recent (tap -> clickAt dispatch?) ==="
grep -aiE 'clickAt|tap|singleTap|mouse' "$D/adapter.log" 2>/dev/null | tail -10
echo "=== adapter.log tail (any content) ==="
tail -4 "$D/adapter.log" 2>/dev/null
echo "=== is the example.com card still open? ==="
luna-send -n 1 palm://com.palm.applicationManager/running '{}' 2>/dev/null | grep -c jihad | sed 's/^/ jihad cards: /'
