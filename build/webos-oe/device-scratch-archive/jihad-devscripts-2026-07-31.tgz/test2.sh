#!/bin/sh
D=/media/internal/jihad
: > "$D/adapter.log" 2>/dev/null
DLOG=$(wc -l < "$D/upstart-daemon.log" 2>/dev/null || echo 0)
MARK=$(date +%s)
echo "=== launch (single) ==="
luna-send -n 1 palm://com.palm.applicationManager/launch '{"id":"net.riverstonerelay.jihad-browser"}' 2>&1 | head -1
sleep 10
echo "=== override marker in log? (the smoking gun) ==="
grep -a 'Jihad\] WebView\|x-jihad-browser' /var/log/messages 2>/dev/null | tail -3 || echo " NO [Jihad] marker"
echo "=== jihad daemon log (new since launch) -- did adapter connect? ==="
tail -n +$((DLOG+1)) "$D/upstart-daemon.log" 2>/dev/null | tail -20
echo "=== adapter.log ==="
tail -12 "$D/adapter.log" 2>/dev/null | head -12
echo "=== which socket did the app connect to? (fd check on card proc) ==="
CPID=$(luna-send -n 1 palm://com.palm.applicationManager/running '{}' 2>/dev/null | sed 's/},{/}\n{/g' | grep -i jihad | grep -oiE 'processid[": ]+[0-9]+' | grep -oE '[0-9]+' | head -1)
echo " jihad card processid: ${CPID:-none}"
echo "=== health ==="
echo " loadavg: $(cut -d' ' -f1-3 /proc/loadavg)  jihad daemon: $(ps -ef|grep -c '[j]ihad-browserserver')"
