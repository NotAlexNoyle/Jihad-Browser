#!/bin/sh
D=/media/internal/jihad
/sbin/stop jihad 2>/dev/null; sleep 2; /sbin/start jihad 2>/dev/null; sleep 3
CP=$(luna-send -n 1 palm://com.palm.applicationManager/running '{}' 2>/dev/null | sed 's/},{/}\n{/g' | grep -i jihad | grep -oiE 'processid[": ]+[0-9]+' | grep -oE '[0-9]+' | head -1)
[ -n "$CP" ] && luna-send -n 1 palm://com.palm.applicationManager/close "{\"processId\":\"$CP\"}" 2>/dev/null >/dev/null
sleep 2
luna-send -n 1 palm://com.palm.applicationManager/launch '{"id":"net.riverstonerelay.jihad-browser","params":{"target":"data:text/html,<body style=font-size:38px><input placeholder=tap-here style=font-size:38px;width:90%25><br><br><a href=http://example.net/>go-example-net</a></body>"}}' 2>&1 | head -1
sleep 9
echo "md5:$(md5sum $D/hl/jihad-browserserver 2>/dev/null|cut -d' ' -f1) card:$(luna-send -n 1 palm://com.palm.applicationManager/running '{}' 2>/dev/null|grep -c jihad) load:$(cut -d' ' -f1 /proc/loadavg)"
echo "=== paints (zoom stable? no oscillation) ==="
grep -a 'painted' "$D/upstart-daemon.log" 2>/dev/null | tail -4
