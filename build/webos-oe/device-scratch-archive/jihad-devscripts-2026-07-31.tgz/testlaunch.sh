#!/bin/sh
D=/media/internal/jihad
P='{"id":"net.riverstonerelay.jihad-browser","params":{"target":"about:jihad"}}'
n(){ luna-send -n 1 palm://com.palm.applicationManager/running '{}' 2>/dev/null | grep -oc '"id":"net.riverstonerelay.jihad-browser"'; }
# bounded: max 2 launches (fresh-open crash), stop when connected
for t in 1 2; do
  grep -q "client connected" "$D/upstart-daemon.log" 2>/dev/null && break
  luna-send -n 1 palm://com.palm.applicationManager/launch "$P" >/dev/null 2>&1
  sleep 12
done
sleep 2
echo "connected: $(grep -c 'client connected' "$D/upstart-daemon.log")"
echo "painted: $(grep -c 'painted' "$D/upstart-daemon.log")"
grep -E 'connect|painted|load done' "$D/upstart-daemon.log" | grep -viE 'data:' | tail -4
