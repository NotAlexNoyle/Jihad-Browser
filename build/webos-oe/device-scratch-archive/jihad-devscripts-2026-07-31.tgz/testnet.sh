#!/bin/sh
D=/media/internal/jihad
CP=$(luna-send -n 1 palm://com.palm.applicationManager/running '{}' 2>/dev/null | sed 's/},{/}\n{/g' | grep -i jihad | grep -oiE 'processid[": ]+[0-9]+' | grep -oE '[0-9]+' | head -1)
[ -n "$CP" ] && luna-send -n 1 palm://com.palm.applicationManager/close "{\"processId\":\"$CP\"}" 2>/dev/null >/dev/null
sleep 2
DLOG=$(wc -l < "$D/upstart-daemon.log" 2>/dev/null || echo 0)
echo "=== direct openUrl http://example.net (isolate: does .net load at all?) ==="
luna-send -n 1 palm://com.palm.applicationManager/launch '{"id":"net.riverstonerelay.jihad-browser","params":{"target":"http://example.net/"}}' 2>&1 | head -1
sleep 12
tail -n +$((DLOG+1)) "$D/upstart-daemon.log" 2>/dev/null | grep -aiE 'openUrl|load done uri=|loaderr|painted bytes' | tail -8
