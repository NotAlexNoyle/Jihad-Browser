#!/bin/sh
D=/media/internal/jihad
APP=/media/cryptofs/apps/usr/palm/applications/net.riverstonerelay.jihad-browser
cp $D/BrowserAdapterImpl.so.new $APP/BrowserAdapterImpl.so
cp $D/BrowserAdapterImpl.so.new $D/BrowserAdapterImpl.so
chmod 755 $APP/BrowserAdapterImpl.so $D/BrowserAdapterImpl.so
touch $D/testpat
echo "impl md5: $(md5sum $APP/BrowserAdapterImpl.so | cut -c1-12), testpat armed"
# reopen card to reload impl (shim dlcloses old, dlopens new)
CP=$(luna-send -n 1 palm://com.palm.applicationManager/running '{}' 2>/dev/null | tr '{' '\n' | grep 'jihad-browser' | grep -oE 'processid[^0-9]*[0-9]+' | grep -oE '[0-9]+' | head -1)
[ -n "$CP" ] && luna-send -n 1 palm://com.palm.applicationManager/close "{\"processId\":\"$CP\"}" 2>/dev/null >/dev/null
sleep 4
luna-send -n 1 palm://com.palm.applicationManager/launch '{"id":"net.riverstonerelay.jihad-browser","params":{"target":"data:text/html,<meta name=viewport content=width=device-width><body style=margin:0><div style=height:300px;background:%23ff0000>X</div></body>"}}' 2>/dev/null | head -1
sleep 9
dd if=/dev/fb1 of=$D/fbtestpat.bgra bs=4096 count=768 2>/dev/null
echo "shim reload:"; tail -1 $D/shim.log
