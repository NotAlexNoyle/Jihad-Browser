#!/bin/sh
D=/media/internal/jihad
CP=$(luna-send -n 1 palm://com.palm.applicationManager/running '{}' 2>/dev/null | sed 's/},{/}\n{/g' | grep -i jihad | grep -oiE 'processid[": ]+[0-9]+' | grep -oE '[0-9]+' | head -1)
[ -n "$CP" ] && luna-send -n 1 palm://com.palm.applicationManager/close "{\"processId\":\"$CP\"}" 2>/dev/null >/dev/null
sleep 2
luna-send -n 1 palm://com.palm.applicationManager/launch '{"id":"net.riverstonerelay.jihad-browser","params":{"target":"http://example.com/"}}' 2>&1 | head -1
sleep 11
dd if=/dev/fb1 of="$D/fb1real.bgra" bs=4096 count=768 2>/dev/null
echo "last paint: $(grep -a painted $D/upstart-daemon.log 2>/dev/null | tail -1 | sed 's/.*bytes=/bytes=/')  captured $(wc -c < $D/fb1real.bgra)"
