#!/bin/sh
D=/media/internal/jihad
echo "before: daemon=$(ps -ef | grep -c '[j]ihad-browserserver')"
echo "keepalive.on exists: $([ -f "$D/keepalive.on" ] && echo yes || echo no)"
echo "sup log tail:"; tail -3 "$D/keepalive-sup.log" 2>/dev/null
# kill the daemon and see if the supervisor respawns it
/usr/bin/pkill -9 -f jihad-browserserver
sleep 4
echo "after kill+4s: daemon=$(ps -ef | grep -c '[j]ihad-browserserver')  (1 = supervisor respawned it => persistent works)"
