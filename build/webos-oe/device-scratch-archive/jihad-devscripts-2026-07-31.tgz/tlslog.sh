grep -aE "iana|navigate|openUrl|state top|loaderr|certErr|SSL|load done|NSS|https" /media/internal/jihad/upstart-daemon.log 2>/dev/null | tail -45
