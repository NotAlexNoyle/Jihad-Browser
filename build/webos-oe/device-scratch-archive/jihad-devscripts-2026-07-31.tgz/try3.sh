#!/bin/sh
P='{"id":"net.riverstonerelay.jihad-browser","params":{"target":"about:jihad"}}'
n(){ luna-send -n 1 palm://com.palm.applicationManager/running '{}' 2>/dev/null | tr '}' '\n' | grep -c 'net.riverstonerelay.jihad-browser'; }
for t in 1 2 3 4; do
  [ "$(n)" -ge 1 ] && { echo "up (attempt $t)"; break; }
  luna-send -n 1 palm://com.palm.applicationManager/launch "$P" >/dev/null 2>&1
  sleep 12
done
echo "running: $(n)"
