#!/bin/sh
D=/media/internal/jihad
echo "=== paints + state around typing (bytes=0 = white) ==="
grep -aiE 'painted|editorFocused|vkb tag|load done|emitGeometry|state top' "$D/upstart-daemon.log" 2>/dev/null | tail -25
echo "daemon-pid:$(ps -ef|grep '[j]ihad-browserserver'|awk '{print $2}'|head -1)"
