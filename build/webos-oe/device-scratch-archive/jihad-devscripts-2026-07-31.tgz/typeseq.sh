#!/bin/sh
D=/media/internal/jihad
echo "=== respawns total + recent full sequence (vkb/editorFocused/state/engine up) ==="
echo "respawns: $(grep -c 'engine up' $D/upstart-daemon.log 2>/dev/null)"
grep -anE 'vkb tag=\[INPUT\]|editorFocused|engine up|content-nav|state top.*START|state top.*STOP status=0x804b|load done' "$D/upstart-daemon.log" 2>/dev/null | tail -18
echo "daemon-pid:$(ps -ef|grep '[j]ihad-browserserver'|awk '{print $2}'|head -1)"
