#!/bin/sh
D=/media/internal/jihad
CP=$(luna-send -n 1 palm://com.palm.applicationManager/running '{}' 2>/dev/null | tr '{' '\n' | grep 'jihad-browser' | grep -oE 'processid[^0-9]*[0-9]+' | grep -oE '[0-9]+' | head -1)
[ -n "$CP" ] && luna-send -n 1 palm://com.palm.applicationManager/close "{\"processId\":\"$CP\"}" 2>/dev/null >/dev/null
sleep 4
luna-send -n 1 palm://com.palm.applicationManager/launch '{"id":"net.riverstonerelay.jihad-browser","params":{"target":"data:text/html,<meta name=viewport content=width=device-width><body style=background:%23bbddff;font-size:40px;padding:30px>Tap box, then type:<br><br><input style=font-size:36px;width:85%25;padding:12px;background:white></body>"}}' 2>/dev/null | head -1
sleep 8
PID0=$(ps -ef|grep '[j]ihad-browserserver'|awk '{print $2}'|head -1)
MARK=$(wc -l < $D/upstart-daemon.log)
echo "card up, daemon PID0=$PID0. TAP box + TYPE now..."
i=0; seen=0
while [ $i -lt 24 ]; do
  sleep 4
  tail -30 $D/upstart-daemon.log | grep -a 'editorFocused=1' >/dev/null && seen=1
  [ $seen -eq 1 ] && break
  i=$((i+1))
done
echo "focus=$seen; 12s to type..."; sleep 12
PID1=$(ps -ef|grep '[j]ihad-browserserver'|awk '{print $2}'|head -1)
echo "daemon $PID0 -> $PID1 $([ "$PID0" = "$PID1" ] && echo STABLE || echo CRASHED)"
echo "=== typing trace (keyDown/insertStr/InsertText/KeyEvent) ==="
tail -n +$((MARK+1)) $D/upstart-daemon.log | grep -aE 'keyDown|insertStringAtCursor|InsertText|KeyEvent skip|editorFocused' | tail -25
