#!/bin/sh
D=/media/internal/jihad
echo "=== last 18 daemon lines (typing path) ==="
tail -18 $D/upstart-daemon.log | grep -aE 'editorFocused|vkb tag|insertStr|InsertText|keyDown|SELFTEST|painted|state top'
