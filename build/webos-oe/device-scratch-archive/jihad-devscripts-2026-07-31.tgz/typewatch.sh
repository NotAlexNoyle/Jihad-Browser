#!/bin/sh
D=/media/internal/jihad
PID0=$(ps -ef|grep '[j]ihad-browserserver'|awk '{print $2}'|head -1)
MARK=$(wc -l < $D/upstart-daemon.log)
echo "waiting for editorFocused (tap box + type now)..."
i=0; seen=0
while [ $i -lt 24 ]; do
  sleep 4
  tail -25 $D/upstart-daemon.log | grep -a 'editorFocused=1' >/dev/null && seen=1
  [ $seen -eq 1 ] && break
  i=$((i+1))
done
echo "editorFocused=$seen; 14s to type..."; sleep 14
dd if=/dev/fb1 of=$D/fbtype.bgra bs=4096 count=768 2>/dev/null
PID1=$(ps -ef|grep '[j]ihad-browserserver'|awk '{print $2}'|head -1)
echo "daemon $PID0 -> $PID1 $([ "$PID0" = "$PID1" ] && echo STABLE || echo CRASHED)"
echo "=== trace ==="
tail -n +$((MARK+1)) $D/upstart-daemon.log | grep -aE 'editorFocused|vkb tag|insertStr|keyDown|painted' | tail -12
