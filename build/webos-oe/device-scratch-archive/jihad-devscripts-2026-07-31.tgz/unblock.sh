#!/bin/sh
/usr/bin/luna-send -n 1 palm://com.palm.applicationManager/launch '{"id":"net.riverstonerelay.jihad-browser","params":{"target":"data:text/html,<h1>Jihad Browser</h1><p>ready</p>"}}'
