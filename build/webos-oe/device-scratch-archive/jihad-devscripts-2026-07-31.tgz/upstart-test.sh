#!/bin/sh
D=/media/internal/jihad
: > "$D/integ-d.log"
/sbin/start browserserver 2>&1 | tail -1
sleep 3
echo "serving: $(grep -c "serving YAP 'browser'" "$D/integ-d.log")"
echo "daemon pid: $(ps -ef | grep -c '[j]ihad-browserserver')"
# THE persistence test: kill the daemon, upstart should respawn it
echo "--- killing daemon to test upstart respawn ---"
/usr/bin/pkill -9 -f jihad-browserserver
sleep 4
echo "after kill+4s serving-count: $(grep -c "serving YAP 'browser'" "$D/integ-d.log")  (2 = upstart respawned it)"
echo "daemon pid now: $(ps -ef | grep -c '[j]ihad-browserserver')  (1 = alive => PERSISTENT)"
