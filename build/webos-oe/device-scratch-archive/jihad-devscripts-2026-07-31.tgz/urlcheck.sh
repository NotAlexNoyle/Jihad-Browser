#!/bin/sh
D=/media/internal/jihad
echo "=== daemon: LoadUrl / openUrl lines (what URL failed with 0x804b001e) ==="
grep -aiE 'LoadUrl|openUrl|load done uri|loaderr' "$D/upstart-daemon.log" 2>/dev/null | tail -15
echo "=== app console: what URL did the WebView navigate to ==="
grep -aiE 'jihad-browser.*(url|http|about:|startpage|file://|load)' /var/log/messages 2>/dev/null | grep -aiv 'x-jihad-browser' | tail -8
echo "=== settle: is the daemon spinning on repaint? (2 samples 4s apart) ==="
J=$(ps -ef 2>/dev/null | grep '[j]ihad-browserserver' | awk '{print $2}' | head -1)
T1=$(awk '{print $14+$15}' /proc/$J/stat 2>/dev/null)
sleep 4
T2=$(awk '{print $14+$15}' /proc/$J/stat 2>/dev/null)
echo " daemon CPU ticks in 4s: $((T2-T1)) (100=fully pegged)"
echo " loadavg: $(cut -d' ' -f1-3 /proc/loadavg)"
