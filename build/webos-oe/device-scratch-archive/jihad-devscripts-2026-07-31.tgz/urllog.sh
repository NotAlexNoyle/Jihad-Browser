grep -aE "openUrl|navigate|LinkClicked|https|certErr|load done|scheme" /media/internal/jihad/upstart-daemon.log 2>/dev/null | tail -30
