#!/bin/sh
D=/media/internal/jihad
: > "$D/adapter.log" 2>/dev/null
# mark daemon log position
LOGLINES=$(wc -l < "$D/upstart-daemon.log" 2>/dev/null || echo 0)
echo "=== single launch of Jihad Browser ==="
luna-send -n 1 palm://com.palm.applicationManager/launch '{"id":"net.riverstonerelay.jihad-browser"}' 2>&1 | head -1
sleep 9
echo "=== daemon log (new lines since launch) ==="
tail -n +$((LOGLINES+1)) "$D/upstart-daemon.log" 2>/dev/null | tail -25
echo "=== adapter.log (adapter side) ==="
tail -15 "$D/adapter.log" 2>/dev/null
echo "=== health ==="
echo " jihad daemon: $(ps -ef 2>/dev/null | grep -c '[j]ihad-browserserver')  LunaSysMgr: $(ps -ef 2>/dev/null | grep -c '[L]unaSysMgr')"
echo " jihad card  : $(luna-send -n 1 palm://com.palm.applicationManager/running '{}' 2>/dev/null | grep -c jihad)"
echo " loadavg     : $(cut -d' ' -f1-3 /proc/loadavg)"
