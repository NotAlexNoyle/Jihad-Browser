#!/bin/sh
echo "device-md5:"; md5sum /media/internal/jihad/hl/jihad-browserserver
chmod +x /media/internal/jihad/hl/jihad-browserserver
