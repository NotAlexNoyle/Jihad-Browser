#!/bin/sh
D=/media/internal/jihad
echo "=== daemon: did it load the data: link page? ==="
grep -aiE 'openUrl|load done uri=' "$D/upstart-daemon.log" 2>/dev/null | tail -4
echo "=== capture fb1 to see if the blue link shows ==="
dd if=/dev/fb1 of="$D/fb1big.bgra" bs=4096 count=768 2>/dev/null
echo "captured $(wc -c < $D/fb1big.bgra) bytes"
echo "loadavg: $(cut -d' ' -f1-3 /proc/loadavg)"
