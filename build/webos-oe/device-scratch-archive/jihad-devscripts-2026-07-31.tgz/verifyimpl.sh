#!/bin/sh
echo "pushed md5: $(md5sum /media/internal/jihad/BrowserAdapterImpl.so.new | cut -c1-12) size=$(wc -c < /media/internal/jihad/BrowserAdapterImpl.so.new)"
