#!/bin/sh
D=/media/internal/jihad
echo "=== last 40 relevant daemon lines (VKB raise -> resize -> paint) ==="
grep -aiE 'editorFocused|setWindowSize|winsize|resize|painted|contentSize|emitGeometry|blank|suppress' $D/upstart-daemon.log 2>/dev/null | tail -40
echo "=== daemon pid ==="; ps -ef|grep '[j]ihad-browserserver'|awk '{print $2}'|head -1
