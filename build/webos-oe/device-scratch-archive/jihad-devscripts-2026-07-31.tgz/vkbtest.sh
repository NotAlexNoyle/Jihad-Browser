#!/bin/sh
D=/media/internal/jihad
MARK=$(wc -l < $D/adapter.log)
echo "waiting for editorFocused (tap box now)..."
i=0; seen=0
while [ $i -lt 22 ]; do
  sleep 4
  tail -30 $D/upstart-daemon.log | grep -a 'editorFocused=1' >/dev/null && seen=1
  [ $seen -eq 1 ] && break
  i=$((i+1))
done
echo "editorFocused=$seen; settle 5s..."
sleep 5
dd if=/dev/fb1 of=$D/fbvkb.bgra bs=4096 count=768 2>/dev/null
echo "=== [hp] blits since tap (dst vs buffer geometry) ==="
tail -n +$((MARK+1)) $D/adapter.log | grep -a '\[hp\]'
echo "=== daemon paints (last 6) ==="; grep -aE 'painted|editorFocused' $D/upstart-daemon.log | tail -6
echo "daemon:$(ps -ef|grep '[j]ihad-browserserver'|awk '{print $2}'|head -1)"
