#!/bin/sh
D=/media/internal/jihad
START=$(wc -l < "$D/upstart-daemon.log" 2>/dev/null || echo 0)
i=0; kb=0; ttl=0
while [ $i -lt 24 ]; do
  sleep 5
  NEW=$(tail -n +$((START+1)) "$D/upstart-daemon.log" 2>/dev/null)
  echo "$NEW" | grep -a 'editorFocused=1' >/dev/null && kb=1
  echo "$NEW" | grep -a 'titleAndUrl.*example.net' >/dev/null && ttl=1
  H=$(echo "$NEW" | grep -c 'clickAt (')
  if [ "$H" -gt 0 ]; then
    echo "--- taps=$H kb=$kb titleUpdated=$ttl ---"
    echo "$NEW" | grep -aiE 'clickAt \(|vkb tag|editorFocused|titleAndUrl|content-nav|load done uri=http' | tail -8
  fi
  [ "$kb" = 1 ] && [ "$ttl" = 1 ] && { echo "*** keyboard-focus + address-bar-update BOTH seen ***"; break; }
  i=$((i+1))
done
echo "final kb=$kb titleUpdated=$ttl daemon=$(ps -ef|grep -c '[j]ihad-browserserver') load=$(cut -d' ' -f1 /proc/loadavg)"
