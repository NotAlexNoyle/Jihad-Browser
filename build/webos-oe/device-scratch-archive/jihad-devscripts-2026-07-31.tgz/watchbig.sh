#!/bin/sh
D=/media/internal/jihad
START=$(wc -l < "$D/upstart-daemon.log" 2>/dev/null || echo 0)
i=0
while [ $i -lt 22 ]; do
  sleep 5
  NEW=$(tail -n +$((START+1)) "$D/upstart-daemon.log" 2>/dev/null)
  HIT=$(echo "$NEW" | grep -c 'clickAt hittest')
  NAV=$(echo "$NEW" | grep -a 'load done uri=' | grep -a 'example.net' | tail -1)
  if [ "$HIT" -gt 0 ]; then
    echo "=== taps: $HIT ==="
    echo "$NEW" | grep -a 'clickAt hittest' | tail -3
    if [ -n "$NAV" ]; then echo "*** LINK FOLLOWED -> $NAV ***"; break; fi
    echo "$NEW" | grep -aiE 'state top.*START|load done uri=|loaderr|failedLoad' | tail -4
  fi
  i=$((i+1))
done
echo "=== final URL ==="; grep -a 'load done uri=' "$D/upstart-daemon.log" 2>/dev/null | tail -1
