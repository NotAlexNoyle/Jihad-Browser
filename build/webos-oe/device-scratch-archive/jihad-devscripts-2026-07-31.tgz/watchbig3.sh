#!/bin/sh
D=/media/internal/jihad
START=$(wc -l < "$D/upstart-daemon.log" 2>/dev/null || echo 0)
i=0
while [ $i -lt 20 ]; do
  sleep 5
  NEW=$(tail -n +$((START+1)) "$D/upstart-daemon.log" 2>/dev/null)
  HIT=$(echo "$NEW" | grep -c 'clickAt (')
  NAV=$(echo "$NEW" | grep -a 'load done uri=http://example.net' | tail -1)
  if [ "$HIT" -gt 0 ]; then
    echo "=== taps: $HIT ==="
    echo "$NEW" | grep -a 'clickAt (' | tail -3
    if [ -n "$NAV" ]; then echo "*** NAVIGATED TO EXAMPLE.NET -> link works! ***"; echo "$NAV"; break; fi
    echo "$NEW" | grep -aiE 'openUrl http://example.net|state top.*START' | tail -3
  fi
  i=$((i+1))
done
echo "=== final URL ==="; grep -a 'load done uri=' "$D/upstart-daemon.log" 2>/dev/null | tail -1 | cut -c1-70
