#!/bin/sh
D=/media/internal/jihad
PID0=$(ps -ef 2>/dev/null | grep '[j]ihad-browserserver' | awk '{print $2}' | head -1)
START=$(wc -l < "$D/upstart-daemon.log" 2>/dev/null || echo 0)
i=0; kb=0; crashed=0
while [ $i -lt 22 ]; do
  sleep 5
  NEW=$(tail -n +$((START+1)) "$D/upstart-daemon.log" 2>/dev/null)
  echo "$NEW" | grep -a 'editorFocused=1' >/dev/null && kb=1
  PIDNOW=$(ps -ef 2>/dev/null | grep '[j]ihad-browserserver' | awk '{print $2}' | head -1)
  [ -n "$PIDNOW" ] && [ "$PIDNOW" != "$PID0" ] && crashed=1
  H=$(echo "$NEW" | grep -c 'clickAt (\|vkb tag')
  if [ "$H" -gt 0 ]; then
    echo "--- events=$H daemon $PID0->$PIDNOW $([ "$crashed" = 1 ] && echo CRASHED || echo STABLE) kb=$kb ---"
    echo "$NEW" | grep -aiE 'vkb tag|editorFocused|engine up' | tail -6
  fi
  i=$((i+1))
done
echo "final: daemon $PID0->$PIDNOW crashed=$crashed kb=$kb"
