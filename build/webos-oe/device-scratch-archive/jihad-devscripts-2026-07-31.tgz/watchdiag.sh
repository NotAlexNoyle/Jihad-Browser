#!/bin/sh
D=/media/internal/jihad
START=$(wc -l < "$D/upstart-daemon.log" 2>/dev/null || echo 0)
i=0; sawvkb=0; sawtitle=0
while [ $i -lt 24 ]; do
  sleep 5
  NEW=$(tail -n +$((START+1)) "$D/upstart-daemon.log" 2>/dev/null)
  echo "$NEW" | grep -a 'vkb ' >/dev/null && sawvkb=1
  echo "$NEW" | grep -a 'titleAndUrl' >/dev/null && sawtitle=1
  H=$(echo "$NEW" | grep -c 'clickAt (')
  if [ "$H" -gt 0 ]; then
    echo "--- taps=$H ---"
    echo "$NEW" | grep -aiE 'clickAt \(|vkb |editorFocused|titleAndUrl|load done uri=http' | tail -8
  fi
  [ "$sawvkb" = 1 ] && [ "$sawtitle" = 1 ] && { echo "*** got vkb-check + titleAndUrl ***"; break; }
  i=$((i+1))
done
echo "final vkb=$sawvkb title=$sawtitle daemon=$(ps -ef|grep -c '[j]ihad-browserserver') load=$(cut -d' ' -f1 /proc/loadavg)"
