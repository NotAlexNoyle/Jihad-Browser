#!/bin/sh
D=/media/internal/jihad
JPID=$(ps -ef 2>/dev/null | grep '[j]ihad-browserserver' | awk '{print $2}' | head -1)
START=$(wc -l < "$D/upstart-daemon.log" 2>/dev/null || echo 0)
i=0
while [ $i -lt 20 ]; do
  sleep 5
  NEW=$(tail -n +$((START+1)) "$D/upstart-daemon.log" 2>/dev/null)
  HIT=$(echo "$NEW" | grep -c 'clickAt ')
  NAV=$(echo "$NEW" | grep -a 'load done uri=http://example.net' | tail -1)
  NOWPID=$(ps -ef 2>/dev/null | grep '[j]ihad-browserserver' | awk '{print $2}' | head -1)
  if [ "$HIT" -gt 0 ]; then
    echo "=== taps: $HIT  daemon pid: $JPID->$NOWPID $([ "$JPID" = "$NOWPID" ] && echo ALIVE-nocrash || echo RESPAWNED-CRASHED) ==="
    echo "$NEW" | grep -aiE 'clickAt|navigate|load done uri=http' | tail -5
    if [ -n "$NAV" ]; then echo "*** NAVIGATED + no crash -> H-1/H-2 FIXED ***"; break; fi
  fi
  i=$((i+1))
done
echo "final: daemon pid $NOWPID, device up $(cut -d. -f1 /proc/uptime)s, load $(cut -d' ' -f1 /proc/loadavg)"
