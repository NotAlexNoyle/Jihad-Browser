#!/bin/sh
D=/media/internal/jihad
START=$(wc -l < "$D/upstart-daemon.log" 2>/dev/null || echo 0)
i=0; sawkb=0; sawnav=0
while [ $i -lt 24 ]; do
  sleep 5
  NEW=$(tail -n +$((START+1)) "$D/upstart-daemon.log" 2>/dev/null)
  echo "$NEW" | grep -a 'editorFocused=1' >/dev/null && sawkb=1
  echo "$NEW" | grep -a 'load done uri=http://example.net' >/dev/null && sawnav=1
  H=$(echo "$NEW" | grep -c 'clickAt ')
  if [ "$H" -gt 0 ]; then
    echo "--- taps=$H  keyboard=$sawkb  nav=$sawnav ---"
    echo "$NEW" | grep -aiE 'clickAt \(|editorFocused|clickAt ->|load done uri=http' | tail -6
  fi
  [ "$sawkb" = "1" ] && [ "$sawnav" = "1" ] && { echo "*** keyboard-focus + link-nav BOTH seen ***"; break; }
  i=$((i+1))
done
echo "final: keyboard=$sawkb nav=$sawnav; url=$(grep -a 'load done uri=' $D/upstart-daemon.log 2>/dev/null|tail -1|cut -c1-45); daemon=$(ps -ef|grep -c '[j]ihad-browserserver') load=$(cut -d' ' -f1 /proc/loadavg)"
