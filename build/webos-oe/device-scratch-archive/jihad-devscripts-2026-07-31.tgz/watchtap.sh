#!/bin/sh
D=/media/internal/jihad
START=$(wc -l < "$D/upstart-daemon.log" 2>/dev/null || echo 0)
i=0
while [ $i -lt 22 ]; do
  sleep 5
  NEW=$(tail -n +$((START+1)) "$D/upstart-daemon.log" 2>/dev/null)
  HIT=$(echo "$NEW" | grep -c 'clickAt hittest')
  # navigation to something OTHER than example.com == link followed
  NAV=$(echo "$NEW" | grep -a 'load done uri=' | grep -av 'example.com' | tail -1)
  ASTART=$(echo "$NEW" | grep -c 'f=0xf0001.*START')
  if [ "$HIT" -gt 0 ]; then
    echo "=== taps seen: $HIT ==="
    echo "$NEW" | grep -a 'clickAt hittest' | tail -4
    echo "--- full-nav STARTs after taps: $ASTART ---"
    if [ -n "$NAV" ]; then echo "*** NAVIGATED AWAY: $NAV ***"; break; fi
    echo "$NEW" | grep -a 'load done uri=\|loaderr\|failedLoad\|FailedLoad' | tail -4
    # keep watching a bit more for the nav to land
  fi
  i=$((i+1))
done
echo "=== final current URL ==="; grep -a 'load done uri=' "$D/upstart-daemon.log" 2>/dev/null | tail -1
