#!/bin/sh
D=/media/internal/jihad
PID0=$(ps -ef 2>/dev/null | grep '[j]ihad-browserserver' | awk '{print $2}' | head -1)
START=$(wc -l < "$D/upstart-daemon.log" 2>/dev/null || echo 0)
i=0; kb=0
while [ $i -lt 22 ]; do
  sleep 5
  NEW=$(tail -n +$((START+1)) "$D/upstart-daemon.log" 2>/dev/null)
  echo "$NEW" | grep -a 'editorFocused=1' >/dev/null && kb=1
  PIDNOW=$(ps -ef 2>/dev/null | grep '[j]ihad-browserserver' | awk '{print $2}' | head -1)
  H=$(echo "$NEW" | grep -c 'editorFocused\|contentSize=0x0\|painted')
  if [ "$H" -gt 0 ]; then
    echo "--- daemon $PID0->$PIDNOW $([ "$PID0" = "$PIDNOW" ] && echo STABLE || echo CRASHED) kb=$kb ---"
    echo "== editorFocused + any 0x0 emits (should be reporting=0) =="
    echo "$NEW" | grep -aiE 'editorFocused|contentSize=.*win=768x602|contentSize=0x0' | tail -4
    echo "== paints after VKB (win 768x602): bytes should stay >0 or be suppressed =="
    echo "$NEW" | grep -a 'painted.*768x602' | tail -4
  fi
  i=$((i+1))
done
echo "final: daemon $PID0->$PIDNOW kb=$kb"
