#!/bin/sh
echo "=== processes mapping BrowserAdapterJihad.so ==="
for p in /proc/[0-9]*; do
  if grep -q 'BrowserAdapterJihad.so' "$p/maps" 2>/dev/null; then
    pid=$(basename $p)
    echo "pid=$pid cmd=$(tr '\0' ' ' < $p/cmdline 2>/dev/null | cut -c1-80)"
  fi
done
echo "=== card running now? ==="
luna-send -n 1 palm://com.palm.applicationManager/running '{}' 2>/dev/null | tr '{' '\n' | grep jihad-browser
echo "=== daemon last paint ==="; grep -a painted /media/internal/jihad/upstart-daemon.log | tail -1
