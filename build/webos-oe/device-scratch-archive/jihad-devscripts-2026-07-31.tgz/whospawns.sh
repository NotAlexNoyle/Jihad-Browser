#!/bin/sh
echo "=== stock BrowserServer + parent ==="
for p in $(ps -ef | grep '[/]usr/bin/BrowserServer ' | awk '{print $2}'); do
  ppid=$(ps -ef | awk -v P=$p '$2==P{print $3}')
  pcmd=$(ps -ef | awk -v P=$ppid '$2==P{for(i=8;i<=NF;i++)printf "%s ",$i; print ""}')
  echo "BrowserServer pid=$p parent=$ppid ($pcmd)"
done
echo "=== who holds /tmp/yapserver.browser (fuser) ==="
fuser /tmp/yapserver.browser 2>/dev/null
echo "=== other browserserver upstart jobs ==="
ls /etc/event.d/ 2>/dev/null | grep -i brows
echo "=== BrowserServerMojo job content (does it spawn stock?) ==="
grep -l 'BrowserServer' /etc/event.d/* 2>/dev/null
