#!/bin/sh
D=/media/internal/jihad
: > "$D/upstart-daemon.log"
P='{"id":"net.riverstonerelay.jihad-browser","params":{"target":"whatismybrowser.com"}}'
luna-send -n 1 palm://com.palm.applicationManager/launch "$P" >/dev/null 2>&1
sleep 18
echo "=== load lifecycle for whatismybrowser (state top + load done) ==="
grep -E 'openUrl|state top|load done uri=http|loaderr' "$D/upstart-daemon.log" | grep -viE 'data:|about' | tail -12
echo "=== NSS flood check (should be 0-few, not hundreds) ==="
grep -c 'forwarded-to-main' "$D/upstart-daemon.log"
echo "=== did it paint content? ==="
grep painted "$D/upstart-daemon.log" | tail -2
