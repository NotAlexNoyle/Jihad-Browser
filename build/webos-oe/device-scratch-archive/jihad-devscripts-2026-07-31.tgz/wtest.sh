#!/bin/sh
D=/media/internal/jihad
/sbin/stop jihad 2>/dev/null; sleep 2; /sbin/start jihad 2>/dev/null; sleep 3
CP=$(luna-send -n 1 palm://com.palm.applicationManager/running '{}' 2>/dev/null | sed 's/},{/}\n{/g' | grep -i jihad | grep -oiE 'processid[": ]+[0-9]+' | grep -oE '[0-9]+' | head -1)
[ -n "$CP" ] && luna-send -n 1 palm://com.palm.applicationManager/close "{\"processId\":\"$CP\"}" 2>/dev/null >/dev/null
sleep 2
luna-send -n 1 palm://com.palm.applicationManager/launch '{"id":"net.riverstonerelay.jihad-browser","params":{"target":"http://example.com/"}}' 2>&1 | head -1
sleep 10
echo "md5:$(md5sum $D/hl/jihad-browserserver 2>/dev/null|cut -d' ' -f1) pid:$(ps -ef|grep '[j]ihad-browserserver'|awk '{print $2}'|head -1) load:$(cut -d' ' -f1 /proc/loadavg)"
echo "=== recent paints (example.com rendered) ==="
grep -a 'painted' "$D/upstart-daemon.log" 2>/dev/null | tail -3
