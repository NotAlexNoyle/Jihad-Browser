#!/bin/sh
D=/media/internal/jihad
echo "deployed libxul md5: $(md5sum $D/hl/libxul.so | cut -c1-12) (expect 8456bbac)"
/sbin/stop jihad 2>/dev/null; sleep 2; /sbin/start jihad 2>/dev/null; sleep 4
echo "daemon pid: $(ps -ef|grep '[j]ihad-browserserver'|awk '{print $2}'|head -1)"
: > $D/adapter.log
luna-send -n 1 palm://com.palm.applicationManager/launch '{"id":"net.riverstonerelay.jihad-browser","params":{"target":"data:text/html,<meta name=viewport content=width=device-width><body style=margin:0><div style=height:200px;background:%23ff0000>RED TOP</div><div style=height:200px;background:%2300ff00>GREEN</div><div style=height:200px;background:%230000ff;color:white>BLUE</div></body>"}}' 2>/dev/null | head -1
sleep 10
dd if=/dev/fb1 of=$D/fbxul.bgra bs=4096 count=768 2>/dev/null
echo "daemon after load: $(ps -ef|grep '[j]ihad-browserserver'|awk '{print $2}'|head -1)"
echo "paint: $(grep -a painted $D/upstart-daemon.log | tail -1)"
