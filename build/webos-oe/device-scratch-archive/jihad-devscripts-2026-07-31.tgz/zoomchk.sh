#!/bin/sh
D=/media/internal/jihad
echo "=== last 15 paints — is mZoom flapping (oscillating) or settled? ==="
grep -a 'painted' "$D/upstart-daemon.log" 2>/dev/null | tail -15 | sed 's/.*bytes=\([0-9]*\).*mZoom=\([0-9.]*\).*/bytes=\1 mZoom=\2/'
echo "=== distinct mZoom values in last 30 paints ==="
grep -a 'painted' "$D/upstart-daemon.log" 2>/dev/null | tail -30 | grep -oE 'mZoom=[0-9.]+' | sort | uniq -c
